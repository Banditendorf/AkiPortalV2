package com.example.akiportal.ui.components

import android.location.Geocoder
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.*
import com.google.maps.android.compose.*
import java.util.*
import androidx.compose.ui.platform.LocalContext


@Composable
fun LocationPickerScreen(
    onLocationSelected: (LatLng, String) -> Unit,
    initialLocation: LatLng = LatLng(38.4192, 27.1287) // İzmir default
) {
    val context = LocalContext.current
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(initialLocation, 12f)
    }

    var selectedPosition by remember { mutableStateOf<LatLng?>(null) }
    var selectedAddress by remember { mutableStateOf("") }

    val markerState = rememberMarkerState()

    // Adres çözümleme işlemini tetikle
    LaunchedEffect(selectedPosition) {
        selectedPosition?.let { latLng ->
            val geocoder = Geocoder(context, Locale.getDefault())
            val addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
            selectedAddress = addresses?.firstOrNull()?.getAddressLine(0) ?: "Adres bulunamadı"
        }
    }

    Column(Modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            cameraPositionState = cameraPositionState,
            onMapClick = { latLng ->
                selectedPosition = latLng
                markerState.position = latLng
            }
        ) {
            selectedPosition?.let {
                Marker(
                    state = markerState,
                    title = "Seçilen Konum",
                    snippet = selectedAddress
                )
            }
        }

        Column(Modifier.padding(16.dp)) {
            Text(
                text = selectedAddress.ifBlank { "Konum seçmek için haritaya dokunun." },
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    selectedPosition?.let {
                        onLocationSelected(it, selectedAddress)
                    }
                },
                enabled = selectedPosition != null
            ) {
                Text("Konumu Kaydet")
            }
        }
    }
}
