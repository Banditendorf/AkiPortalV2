package com.example.akiportal.util

import android.content.Context
import android.content.SharedPreferences
import com.example.akiportal.model.User
import com.example.akiportal.model.UserPermissions
import com.google.gson.Gson

object SharedPrefHelper {

    private const val PREF_NAME = "aki_portal_prefs"
    private const val KEY_EMAIL = "email"
    private const val KEY_REMEMBER = "remember_me"
    private const val KEY_YETKILER = "yetkiler_json"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun saveRememberMe(context: Context, email: String) {
        getPrefs(context).edit().apply {
            putString(KEY_EMAIL, email)
            putBoolean(KEY_REMEMBER, true)
            apply()
        }
    }

    fun clearRememberMe(context: Context) {
        getPrefs(context).edit().apply {
            remove(KEY_EMAIL)
            remove(KEY_YETKILER)
            putBoolean(KEY_REMEMBER, false)
            apply()
        }
    }

    fun getSavedEmail(context: Context): String? {
        return getPrefs(context).getString(KEY_EMAIL, null)
    }

    fun isRemembered(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_REMEMBER, false)
    }

    // ⬇️ Kullanıcı yetkilerini JSON olarak kaydeder
    fun saveUserPermissions(context: Context, user: User) {
        val json = Gson().toJson(user.permissions)
        getPrefs(context).edit().putString(KEY_YETKILER, json).apply()
    }

    // ⬇️ Yetkileri geri alır
    fun getSavedPermissions(context: Context): UserPermissions? {
        val json = getPrefs(context).getString(KEY_YETKILER, null)
        return json?.let { Gson().fromJson(it, UserPermissions::class.java) }
    }
}
