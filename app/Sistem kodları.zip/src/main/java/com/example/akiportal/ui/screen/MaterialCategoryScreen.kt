package com.example.akiportal.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.viewmodel.MaterialViewModel
import com.example.akiportal.ui.theme.BackgroundDark
import com.example.akiportal.ui.theme.White
import com.example.akiportal.util.PermissionManager
import com.example.akiportal.util.PermissionType
import kotlinx.coroutines.launch

@Composable
fun MaterialCategoryScreen(
    navController: NavController,
    viewModel: MaterialViewModel = viewModel()
) {
    val categories by viewModel.categories.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        RedTopBar(title = "Malzeme Kategorileri")

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            items(categories) { category ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clickable {
                            if (PermissionManager.hasPermission(PermissionType.CATEGORY_ADD)) {
                                navController.navigate("materialListByCategory/${category}")
                            } else {
                                scope.launch {
                                    snackbarHostState.showSnackbar("Bu işlem için yetkiniz yok.")
                                }
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = Color.DarkGray)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Category,
                                contentDescription = null,
                                tint = White
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = category,
                                color = White,
                                fontSize = 16.sp
                            )
                        }
                        Icon(
                            imageVector = Icons.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            tint = White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        // Snackbar gösterimi
        SnackbarHost(hostState = snackbarHostState)
    }
}
