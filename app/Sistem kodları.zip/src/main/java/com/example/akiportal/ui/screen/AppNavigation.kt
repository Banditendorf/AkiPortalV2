package com.example.akiportal.ui.screen

import android.net.Uri
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.akiportal.model.Company
import com.example.akiportal.model.Machine
import com.example.akiportal.model.User
import com.example.akiportal.ui.MainMenuScreen
import com.example.akiportal.util.PermissionManager
import com.example.akiportal.util.PermissionType
import com.example.akiportal.viewmodel.*
import com.google.gson.Gson
import kotlinx.coroutines.launch
import com.example.akiportal.ui.screen.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.akiportal.model.Maintenance
import com.example.akiportal.ui.screen.OcrUploadScreen




@Composable
fun AppNavigation(
    navController: NavHostController,
    isLoggedIn: Boolean,
    currentUser: User?,
    onLoginSuccess: (String) -> Unit,
    onLogout: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Box {
        NavHost(
            navController = navController,
            startDestination = if (isLoggedIn) "menu" else "login"
        ) {
            composable("login") {
                LoginScreen(onLoginSuccess = onLoginSuccess)
            }

            composable("menu") {
                currentUser?.let {
                    MainMenuScreen(
                        currentUser = it,
                        onMenuItemClick = { route ->
                            val permission = when (route) {
                                "companies" -> PermissionType.COMPANY_ADD
                                "bakimlar" -> PermissionType.MAINTENANCE_ADD
                                "hazirliklar" -> PermissionType.MAINTENANCE_ADD
                                "malzemeler" -> PermissionType.MATERIAL_ADD
                                "kullanicilar" -> PermissionType.USER_AUTH
                                "ayarlar" -> PermissionType.ALL
                                "logs" -> PermissionType.ALL
                                else -> null
                            }

                            if (permission == null || PermissionManager.hasPermission(permission)) {
                                navController.navigate(route)
                            } else {
                                scope.launch {
                                    snackbarHostState.showSnackbar("Bu işlem için yetkiniz yok.")
                                }
                            }
                        },
                        onNotificationClick = {
                            navController.navigate("bildirimler")
                        }
                    )

                }
            }

            composable("companies") {
                if (PermissionManager.hasPermission(PermissionType.COMPANY_ADD)) {
                    CompanyScreen(
                        navController = navController,
                        onCompanyClick = { company ->
                            val json = Uri.encode(Gson().toJson(company))
                            navController.navigate("companyDetail/$json")
                        }
                    )
                }
            }

            composable(
                "companyDetail/{companyJson}",
                arguments = listOf(navArgument("companyJson") { type = NavType.StringType })
            ) {
                val json = it.arguments?.getString("companyJson")
                val company = Gson().fromJson(json, Company::class.java)
                CompanyDetailScreen(company = company, navController = navController)
            }
            composable("bildirimler") { NotificationScreen() }

            composable(
                "machineDetail/{machineJson}",
                arguments = listOf(navArgument("machineJson") { type = NavType.StringType })
            ) {
                val json = it.arguments?.getString("machineJson")
                val machine = Gson().fromJson(json, Machine::class.java)
                MachineDetailScreen(machine = machine, navController = navController) // 🔧 eksik parametreyi ekledik
            }


            composable("malzemeler") {
                if (PermissionManager.hasPermission(PermissionType.MATERIAL_ADD)) {
                    MaterialScreen(onCategoryClick = { category ->
                        navController.navigate("materialListByCategory/${Uri.encode(category)}")
                    })
                }
            }

            composable(
                "materialListByCategory/{category}",
                arguments = listOf(navArgument("category") { type = NavType.StringType })
            ) {
                val category = it.arguments?.getString("category") ?: ""
                MaterialListByCategoryScreen(category = category)
            }

            composable("bakimlar") {
                PlannedMaintenanceScreen(
                    navController = navController,
                    onAddClick = {
                        navController.navigate("ocrScan") // veya başka bir sayfa
                    }
                )
            }

            composable("hazirliklar") {
                if (PermissionManager.hasPermission(PermissionType.MAINTENANCE_ADD)) {
                    PreparationScreen(
                        onMaintenanceClick = { maintenance: Maintenance ->
                            val json = Uri.encode(Gson().toJson(maintenance))
                            navController.navigate("preparationDetail/$json")
                        }
                    )
                }
            }

            composable(
                "preparationDetail/{maintenanceJson}",
                arguments = listOf(navArgument("maintenanceJson") { type = NavType.StringType })
            ) {
                val json = it.arguments?.getString("maintenanceJson")
                val maintenance = Gson().fromJson(json, Maintenance::class.java)
                PreparationDetailScreen(
                    maintenance = maintenance,
                    currentUser = currentUser!!,
                    onBack = { navController.popBackStack() }
                )
            }




            composable("kullanicilar") {
                if (PermissionManager.hasPermission(PermissionType.USER_AUTH)) {
                    UsersScreen()
                }
            }

            composable("ayarlar") {
                SettingsScreen(
                    onLogout = onLogout,
                    onViewLogsClick = {
                        if (PermissionManager.hasPermission(PermissionType.ALL)) {
                            navController.navigate("logs")
                        } else {
                            scope.launch {
                                snackbarHostState.showSnackbar("Log erişim yetkiniz yok.")
                            }
                        }
                    }
                )
            }
            composable("ocrScan") {
                OcrUploadScreen(
                    onExtracted = { extractedText ->
                        // Burada Firestore karşılaştırması yapabilirsin
                        navController.navigate("maintenancePlanFromOCR/${Uri.encode(extractedText)}")
                    }
                )
            }

            composable(
                "dailyMaintenances/{date}/{maintenancesJson}",
                arguments = listOf(
                    navArgument("date") { type = NavType.StringType },
                    navArgument("maintenancesJson") { type = NavType.StringType }
                )
            ) {
                val date = it.arguments?.getString("date") ?: "-"
                val listJson = it.arguments?.getString("maintenancesJson")
                val maintenances = Gson().fromJson(listJson, Array<Maintenance>::class.java).toList()

                DailyMaintenanceScreen(
                    date = date,
                    maintenances = maintenances,
                    onItemClick = { selected ->
                        val json = Uri.encode(Gson().toJson(selected))
                        navController.navigate("preparationDetail/$json")
                    },
                    onBack = { navController.popBackStack() } // ✅ bu satır eksikti
                )
            }


            composable("logs") {
                if (PermissionManager.hasPermission(PermissionType.ALL)) {
                    LogScreen()
                }
            }
        }

        // ⬇ Snackbar container
        SnackbarHost(hostState = snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter))
    }
}
