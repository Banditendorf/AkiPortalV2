package com.example.akiportal.viewmodel

import androidx.lifecycle.ViewModel
import com.example.akiportal.model.Material
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

class MaterialViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()

    private val _materials = MutableStateFlow<List<Material>>(emptyList())
    val materials: StateFlow<List<Material>> = _materials

    private val _categories = MutableStateFlow<List<String>>(emptyList())
    val categories: StateFlow<List<String>> = _categories

    private val _stockMap = MutableStateFlow<Map<String, Int>>(emptyMap())
    val stockMap: StateFlow<Map<String, Int>> = _stockMap

    init {
        loadMaterials()
    }

    fun loadMaterials() {
        db.collection("materials").get().addOnSuccessListener { result ->
            val allMaterials = mutableListOf<Material>()
            val allCategories = mutableListOf<String>()
            val stock = mutableMapOf<String, Int>()

            for (doc in result.documents) {
                val categoryName = doc.id
                allCategories.add(categoryName)

                val content = doc.get("icerik") as? Map<*, *> ?: continue

                for ((idAny, rawAny) in content) {
                    val raw = rawAny as? Map<*, *> ?: continue
                    val code = raw["code"] as? String ?: continue
                    val brand = raw["brand"] as? String ?: ""
                    val shelf = raw["shelf"] as? String ?: ""
                    val stockValue = (raw["stock"] as? Long)?.toInt() ?: 0
                    val kritik = (raw["kritikStok"] as? Long)?.toInt() ?: 0 // 🔄 Hatalı yeri buraya taşıdık

                    val material = Material(
                        code = code,
                        brand = brand,
                        shelf = shelf,
                        category = categoryName,
                        stock = stockValue,
                        kritikStok = kritik
                    )

                    allMaterials.add(material)
                    stock[code] = stockValue
                }
            }

            _materials.value = allMaterials
            _categories.value = allCategories
            _stockMap.value = stock
        }
    }


    fun addMaterial(material: Material) {
        val docRef = db.collection("materials").document(material.category)
        docRef.get().addOnSuccessListener { snapshot ->
            val content = snapshot.get("icerik") as? Map<String, Any?> ?: mapOf()
            val updatedMap = mutableMapOf<String, Any?>()
            updatedMap.putAll(content)

            val newId = UUID.randomUUID().toString()
            val newMaterial = mapOf(
                "code" to material.code,
                "brand" to material.brand,
                "shelf" to material.shelf,
                "category" to material.category,
                "stock" to material.stock,
                "kritikStok" to material.kritikStok
            )


            updatedMap[newId] = newMaterial
            docRef.set(mapOf("icerik" to updatedMap), SetOptions.merge())
                .addOnSuccessListener { loadMaterials() }
        }
    }

    fun updateStock(category: String, code: String, newStock: Int) {
        val docRef = db.collection("materials").document(category)
        docRef.get().addOnSuccessListener { snapshot ->
            val content = snapshot.get("icerik") as? Map<String, Map<String, Any?>> ?: return@addOnSuccessListener
            val updated = mutableMapOf<String, Map<String, Any?>>()

            for ((key, value) in content) {
                if (value["code"] == code) {
                    val updatedMaterial = value.toMutableMap()
                    updatedMaterial["stock"] = newStock
                    updated[key] = updatedMaterial
                } else {
                    updated[key] = value
                }
            }

            docRef.set(mapOf("icerik" to updated), SetOptions.merge())
                .addOnSuccessListener { loadMaterials() }
        }
    }

    fun addCategory(name: String) {
        db.collection("materials").document(name)
            .set(mapOf("icerik" to mapOf<String, Any>()))
            .addOnSuccessListener { loadMaterials() }
    }

    fun deleteCategory(name: String) {
        db.collection("materials").document(name)
            .delete()
            .addOnSuccessListener { loadMaterials() }
    }

    fun deleteMaterial(material: Material) {
        val docRef = db.collection("materials").document(material.category)
        docRef.get().addOnSuccessListener { snapshot ->
            val content = snapshot.get("icerik") as? Map<String, Map<String, Any?>> ?: return@addOnSuccessListener
            val updated = mutableMapOf<String, Map<String, Any?>>()

            var silindi = false

            for ((key, value) in content) {
                val code = value["code"]?.toString()?.trim()?.lowercase()
                val brand = value["brand"]?.toString()?.trim()?.lowercase()
                val shelf = value["shelf"]?.toString()?.trim()?.lowercase()

                if (
                    code == material.code.trim().lowercase() &&
                    brand == material.brand.trim().lowercase() &&
                    shelf == material.shelf.trim().lowercase()
                ) {
                    silindi = true
                    continue // eşleşti, bu entry silinecek
                }

                updated[key] = value
            }

            if (silindi) {
                docRef.set(mapOf("icerik" to updated), SetOptions.merge())
                    .addOnSuccessListener { loadMaterials() }
            }
        }
    }


    fun updateMaterial(material: Material) {
        val docRef = db.collection("materials").document(material.category)
        docRef.get().addOnSuccessListener { snapshot ->
            val content = snapshot.get("icerik") as? Map<String, Map<String, Any?>> ?: return@addOnSuccessListener
            val updated = mutableMapOf<String, Map<String, Any?>>()

            for ((key, value) in content) {
                if (value["code"] == material.code) {
                    updated[key] = mapOf(
                        "code" to material.code,
                        "brand" to material.brand,
                        "shelf" to material.shelf,
                        "category" to material.category,
                        "stock" to material.stock,
                        "kritikStok" to material.kritikStok
                    )

                } else {
                    updated[key] = value
                }
            }

            docRef.set(mapOf("icerik" to updated), SetOptions.merge())
                .addOnSuccessListener { loadMaterials() }
        }
    }
}