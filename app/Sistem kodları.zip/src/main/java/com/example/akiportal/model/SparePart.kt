package com.example.akiportal.model

data class SparePart(
    val name: String = "",
    val quantity: Int = 1,
    val prepared: Boolean = false,
    val preparedBy: String? = null
)
