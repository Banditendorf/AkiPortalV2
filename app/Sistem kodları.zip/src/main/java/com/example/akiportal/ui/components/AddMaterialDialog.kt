package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.Material

@Composable
fun AddMaterialDialog(
    onDismiss: () -> Unit,
    onAdd: (Material) -> Unit,
    category: String
) {
    var code by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var shelf by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("0") }
    var kritikStok by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val stockInt = stock.toIntOrNull() ?: 0
                val kritikInt = kritikStok.toIntOrNull() ?: 0
                if (code.isNotBlank()) {
                    onAdd(
                        Material(
                            code = code,
                            brand = brand,
                            shelf = shelf,
                            category = category,
                            stock = stockInt,
                            kritikStok = kritikInt
                        )
                    )
                    onDismiss()
                }
            }) {
                Text("Ekle")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        },
        title = { Text("Yeni Malzeme") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Kod") })
                OutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text("Marka") })
                OutlinedTextField(value = shelf, onValueChange = { shelf = it }, label = { Text("Raf") })
                OutlinedTextField(value = stock, onValueChange = { stock = it.filter { it.isDigit() } }, label = { Text("Stok Adedi") })
                OutlinedTextField(value = kritikStok, onValueChange = { kritikStok = it.filter { it.isDigit() } }, label = { Text("Kritik Stok") }) // 🔴 yeni alan
            }
        }
    )
}
