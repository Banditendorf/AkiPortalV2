package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.akiportal.model.Company
import com.example.akiportal.viewmodel.CompanyViewModel
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun CompanyAddDialog(
    onDismiss: () -> Unit,
    navController: NavController,
    viewModel: CompanyViewModel
) {
    var name by remember { mutableStateOf("") }
    var person by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var latLng by remember { mutableStateOf<LatLng?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val db = FirebaseFirestore.getInstance()
                val newDocRef = db.collection("companies").document()
                val newCompany = Company(
                    id = newDocRef.id,
                    name = name,
                    contactPerson = person,
                    contactNumber = number,
                    role = role,
                    location = location,
                    note = note
                )
                newDocRef.set(newCompany)
                    .addOnSuccessListener {
                        viewModel.loadCompanies()
                        onDismiss()
                    }
                    .addOnFailureListener {
                        onDismiss()
                    }
            }) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        },
        title = { Text("Yeni Şirket Ekle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Şirket Adı") })
                OutlinedTextField(value = person, onValueChange = { person = it }, label = { Text("Yetkili Kişi") })
                OutlinedTextField(value = number, onValueChange = { number = it }, label = { Text("Telefon") })
                OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Görevi") })

                Button(onClick = {
                    navController.navigate("locationPicker")
                }) {
                    Text(if (location.isBlank()) "Konum Seç" else "Konum: $location")
                }

                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Not") })
            }
        }
    )

    // Harita dönüş verisi (adres) dinleme
    val savedStateHandle = navController.currentBackStackEntry?.savedStateHandle
    val selectedAddress = savedStateHandle?.getStateFlow<String?>("selectedAddress", null)?.collectAsState()

    LaunchedEffect(selectedAddress?.value) {
        selectedAddress?.value?.let {
            location = it
            savedStateHandle.remove<String>("selectedAddress")
        }
    }
}
