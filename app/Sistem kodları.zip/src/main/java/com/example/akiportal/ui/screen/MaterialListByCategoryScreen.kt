package com.example.akiportal.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.akiportal.model.Material
import com.example.akiportal.ui.components.*
import com.example.akiportal.ui.theme.*
import com.example.akiportal.viewmodel.MaterialViewModel
import com.example.akiportal.util.PermissionManager
import com.example.akiportal.util.PermissionType
import kotlinx.coroutines.launch

@Composable
fun MaterialListByCategoryScreen(
    category: String,
    viewModel: MaterialViewModel = viewModel()
) {
    val materials by viewModel.materials.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var expandedMenu by remember { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showDetailDialog by remember { mutableStateOf<Material?>(null) }
    var showEditDialog by remember { mutableStateOf<Material?>(null) }
    var showDeleteDialog by remember { mutableStateOf<Material?>(null) }

    Column(Modifier.fillMaxSize().background(BackgroundDark)) {
        RedTopBar(title = category, showMenu = true) {
            DropdownMenuItem(
                text = { Text("Malzeme Ekle") },
                onClick = {
                    if (PermissionManager.hasPermission(PermissionType.MATERIAL_ADD)) {
                        showAddDialog = true
                    } else {
                        scope.launch { snackbarHostState.showSnackbar("Bu işlem için yetkiniz yok.") }
                    }
                    expandedMenu = false
                }
            )
            DropdownMenuItem(text = { Text("Excel Rapor (eklenecek)") }, onClick = {})
            DropdownMenuItem(text = { Text("PDF Rapor (eklenecek)") }, onClick = {})
        }

        LazyColumn(Modifier.padding(16.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Kod", color = Color.Gray)
                    Text("Adet", color = Color.Gray)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            items(materials.filter { it.category == category }) { material ->
                var stock by remember { mutableStateOf(material.stock) }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable {
                            if (PermissionManager.hasPermission(PermissionType.MATERIAL_ADD)) {
                                showDetailDialog = material
                            } else {
                                scope.launch { snackbarHostState.showSnackbar("Bu işlem için yetkiniz yok.") }
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = Color.DarkGray)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(material.code, color = Color.White)
                                Text(
                                    "Kritik Stok: ${material.kritikStok}",
                                    color = if (stock <= material.kritikStok) Color.Red else Color.LightGray,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    if (!PermissionManager.hasPermission(PermissionType.STOCK_MANAGEMENT)) {
                                        scope.launch { snackbarHostState.showSnackbar("Yetkisiz işlem!") }
                                        return@IconButton
                                    }
                                    if (stock > 0) {
                                        stock--
                                        viewModel.updateStock(material.category, material.code, stock)
                                    }
                                }) {
                                    Text("-", color = Color.White)
                                }

                                Text("$stock", color = Color.White)

                                IconButton(onClick = {
                                    if (!PermissionManager.hasPermission(PermissionType.STOCK_MANAGEMENT)) {
                                        scope.launch { snackbarHostState.showSnackbar("Yetkisiz işlem!") }
                                        return@IconButton
                                    }
                                    stock++
                                    viewModel.updateStock(material.category, material.code, stock)
                                }) {
                                    Text("+", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAddDialog) {
            AddMaterialDialog(
                category = category,
                onDismiss = { showAddDialog = false },
                onAdd = {
                    viewModel.addMaterial(it)
                    showAddDialog = false
                }
            )
        }

        showDetailDialog?.let { material ->
            MaterialDetailDialog(
                material = material,
                onDismiss = { showDetailDialog = null },
                onEdit = {
                    if (PermissionManager.hasPermission(PermissionType.MATERIAL_ADD)) {
                        showEditDialog = material
                        showDetailDialog = null
                    } else {
                        scope.launch { snackbarHostState.showSnackbar("Bu işlem için yetkiniz yok.") }
                    }
                },
                onDelete = {
                    if (PermissionManager.hasPermission(PermissionType.MATERIAL_DELETE)) {
                        showDeleteDialog = material
                        showDetailDialog = null
                    } else {
                        scope.launch { snackbarHostState.showSnackbar("Bu işlem için yetkiniz yok.") }
                    }
                }
            )
        }

        showEditDialog?.let { material ->
            EditMaterialDialog(
                material = material,
                onDismiss = { showEditDialog = null },
                onSave = {
                    viewModel.updateMaterial(it)
                    showEditDialog = null
                },
                onDelete = {
                    viewModel.deleteMaterial(material)
                    showEditDialog = null
                }
            )
        }

        showDeleteDialog?.let { material ->
            ConfirmDeleteDialog(
                material = material,
                onDismiss = { showDeleteDialog = null },
                onConfirm = {
                    viewModel.deleteMaterial(material)
                    showDeleteDialog = null
                }
            )
        }

        SnackbarHost(hostState = snackbarHostState)
    }
}
