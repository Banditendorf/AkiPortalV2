package com.example.akiportal.model

data class Company(
    val id: String = "",
    val name: String = "",
    val contactPerson: String = "",
    val contactNumber: String = "",
    val location: String = "",
    val note: String = "",
    val role: String = ""
)


