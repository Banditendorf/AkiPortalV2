package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.User
import com.example.akiportal.model.UserPermissions
import com.example.akiportal.ui.theme.RedPrimary
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState

@Composable
fun UserDetailDialog(
    user: User,
    currentUserEmail: String,
    onDismiss: () -> Unit,
    onDelete: (String) -> Unit,
    onToggleActive: (String, Boolean) -> Unit,
    onEditPermissions: (String, UserPermissions) -> Unit,
    onUpdateUser: (String, String, String, String, String) -> Unit,
    isCurrentUser: Boolean
) {
    var fullName by remember { mutableStateOf(user.fullName) }
    var workPhone by remember { mutableStateOf(user.workPhone) }
    var personalPhone by remember { mutableStateOf(user.personalPhone) }
    var role by remember { mutableStateOf(user.role ?: "") }

    var showConfirmDelete by remember { mutableStateOf(false) }
    var showPermissionDialog by remember { mutableStateOf(false) }
    var showEditProfileDialog by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Kapat", color = Color.LightGray) } },
        title = { Text("Kullanıcı Detayları", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .heightIn(max = 500.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Ad Soyad") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = workPhone, onValueChange = { workPhone = it }, label = { Text("İş Telefonu") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = personalPhone, onValueChange = { personalPhone = it }, label = { Text("Kişisel Telefon") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Görevi") }, modifier = Modifier.fillMaxWidth())

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Aktif Kullanıcı")
                    Switch(checked = user.isActive, onCheckedChange = { onToggleActive(user.uid, it) })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            if (isCurrentUser) {
                                showEditProfileDialog = true
                            } else {
                                onUpdateUser(user.uid, fullName, workPhone, personalPhone, role)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Bilgileri Güncelle", color = Color.White)
                    }

                    Button(
                        onClick = { showPermissionDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                        modifier = Modifier.weight(1f),
                        enabled = !isCurrentUser
                    ) {
                        Text("Yetkileri Düzenle", color = Color.White)
                    }
                }

                if (!isCurrentUser) {
                    Button(
                        onClick = { showConfirmDelete = true },
                        colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Kullanıcıyı Sil", color = Color.White)
                    }
                } else {
                    Text("Kendi hesabınızı silemezsiniz.", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    )

    if (showPermissionDialog) {
        EditAuthorizationsDialog(
            initialAuthorizations = user.permissions,
            onDismiss = { showPermissionDialog = false },
            onSave = {
                onEditPermissions(user.uid, it)
                showPermissionDialog = false
            }
        )
    }

    if (showConfirmDelete) {
        AlertDialog(
            onDismissRequest = { showConfirmDelete = false },
            title = { Text("Silme Onayı") },
            text = { Text("Bu kullanıcıyı silmek istediğinizden emin misiniz?") },
            confirmButton = {
                TextButton(onClick = {
                    onDelete(user.uid)
                    showConfirmDelete = false
                    onDismiss()
                }) {
                    Text("Evet")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDelete = false }) {
                    Text("İptal")
                }
            }
        )
    }

    if (showEditProfileDialog) {
        EditMyProfileDialog(
            initialFullName = fullName,
            initialWorkPhone = workPhone,
            initialPersonalPhone = personalPhone,
            initialRole = role, // <-- EKLENDİ
            onDismiss = { showEditProfileDialog = false },
            onSave = { name, work, personal, newRole ->
                onUpdateUser(user.uid, name, work, personal, newRole)
                showEditProfileDialog = false
            }
        )

    }
}