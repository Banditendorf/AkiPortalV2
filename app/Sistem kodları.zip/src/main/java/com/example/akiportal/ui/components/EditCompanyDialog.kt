package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.Company
import com.example.akiportal.viewmodel.CompanyViewModel
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun EditCompanyDialog(
    company: Company,
    onDismiss: () -> Unit,
    onSave: (Company) -> Unit
) {
    var name by remember { mutableStateOf(company.name) }
    var contactPerson by remember { mutableStateOf(company.contactPerson) }
    var contactNumber by remember { mutableStateOf(company.contactNumber) }
    var location by remember { mutableStateOf(company.location) }
    var note by remember { mutableStateOf(company.note) }
    var role by remember { mutableStateOf(company.role) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                onSave(company.copy(
                    name = name,
                    contactPerson = contactPerson,
                    contactNumber = contactNumber,
                    location = location,
                    note = note,
                    role = role
                ))
                onDismiss()
            }) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        },
        title = { Text("Şirket Bilgilerini Güncelle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Şirket Adı") })
                OutlinedTextField(value = contactPerson, onValueChange = { contactPerson = it }, label = { Text("Yetkili Kişi") })
                OutlinedTextField(value = contactNumber, onValueChange = { contactNumber = it }, label = { Text("Telefon") })
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Konum") })
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Not") })
                OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Görevi") })
            }
        }
    )
}
