package com.example.akiportal.model

data class UserPermissions(
    val fullAccess: Boolean = false,
    val addCompany: Boolean = false,
    val deleteCompany: Boolean = false,
    val addMachine: Boolean = false,
    val deleteMachine: Boolean = false,
    val updateMachine: Boolean = false,
    val addMaintenance: Boolean = false,
    val deleteMaintenance: Boolean = false,
    val addCompanyNote: Boolean = false,
    val addMachineNote: Boolean = false,
    val addMaintenanceNote: Boolean = false,
    val addUser: Boolean = false,
    val deleteUser: Boolean = false,
    val editUserRoles: Boolean = false,
    val addMaterial: Boolean = false,
    val deleteMaterial: Boolean = false,
    val addCategory: Boolean = false,
    val deleteCategory: Boolean = false,
    val stockControl: Boolean = false,
    val viewLogs: Boolean = false
)
