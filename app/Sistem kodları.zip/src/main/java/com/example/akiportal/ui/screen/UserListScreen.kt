package com.example.akiportal.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.akiportal.model.User
import com.example.akiportal.ui.components.AddUsersDialog
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.ui.components.UserDetailDialog
import com.example.akiportal.util.PermissionManager
import com.example.akiportal.util.PermissionType
import com.example.akiportal.viewmodel.UserViewModel
import kotlinx.coroutines.launch

@Composable
fun UserListScreen(userViewModel: UserViewModel = viewModel()) {
    var allUsers by remember { mutableStateOf<List<User>>(emptyList()) }
    var currentUser by remember { mutableStateOf<User?>(null) }
    var selectedUser by remember { mutableStateOf<User?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        userViewModel.fetchCurrentUser()
        userViewModel.loadAllUsers()
    }

    LaunchedEffect(Unit) {
        userViewModel.currentUser.collect { currentUser = it }
    }

    LaunchedEffect(Unit) {
        userViewModel.allUsers.collect { allUsers = it }
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF212121))) {
        RedTopBar(title = "Kullanıcılar")

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Kullanıcı Ara") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.weight(1f)
            )

            Button(
                onClick = {
                    if (PermissionManager.hasPermission(PermissionType.USER_ADD)) {
                        showAddDialog = true
                    } else {
                        scope.launch {
                            snackbarHostState.showSnackbar("Bu işlem için yetkiniz yok.")
                        }
                    }
                },
                modifier = Modifier.align(Alignment.CenterVertically)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ekle")
                Spacer(Modifier.width(4.dp))
                Text("Yeni")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        val filteredList = allUsers.filter {
            it.fullName.contains(searchQuery, ignoreCase = true) ||
                    it.email.contains(searchQuery, ignoreCase = true)
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredList) { user ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedUser = user },
                    colors = CardDefaults.cardColors(containerColor = Color.DarkGray)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(user.fullName, color = Color.White)
                        Text(user.email, color = Color.LightGray)
                    }
                }
            }
        }

        if (showAddDialog) {
            AddUsersDialog(
                onDismiss = {
                    showAddDialog = false
                    userViewModel.loadAllUsers()
                },
                userViewModel = userViewModel
            )
        }

        selectedUser?.let { user ->
            UserDetailDialog(
                user = user,
                currentUserEmail = currentUser?.email.orEmpty(),
                onDismiss = {
                    selectedUser = null
                    userViewModel.loadAllUsers()
                },
                onDelete = { uid ->
                    userViewModel.deleteUser(uid)
                    selectedUser = null
                },
                onToggleActive = { uid, newActive ->
                    userViewModel.toggleUserActive(uid, newActive)
                },
                onEditPermissions = { uid, updatedYetkiler ->
                    userViewModel.updateUserPermissions(uid, updatedYetkiler)
                },
                onUpdateUser = { uid, fullName, workPhone, personalPhone, role ->
                    userViewModel.updateUserInfo(uid, fullName, workPhone, personalPhone, role)
                },
                isCurrentUser = user.uid == currentUser?.uid
            )
        }

        SnackbarHost(hostState = snackbarHostState)
    }
}
