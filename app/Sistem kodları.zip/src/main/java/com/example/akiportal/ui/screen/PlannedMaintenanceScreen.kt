package com.example.akiportal.ui.screen

import android.app.DatePickerDialog
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.akiportal.model.Maintenance
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.ui.theme.*
import com.example.akiportal.util.CalendarHelper
import com.example.akiportal.util.CalendarMonthView
import com.example.akiportal.viewmodel.BakimViewModel
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import com.google.gson.Gson



@Composable
fun PlannedMaintenanceScreen(
    navController: NavController,
    viewModel: BakimViewModel = viewModel(),
    onAddClick: () -> Unit // ⬅ OCR veya manuel bakım başlatmak için dışarıdan yönlendirme
) {
    var plannedList by remember { mutableStateOf(emptyList<Maintenance>()) }
    var selectedDate by remember { mutableStateOf<LocalDate?>(null) }

    LaunchedEffect(true) {
        viewModel.getPlannedList {
            plannedList = it
        }
    }

    val formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")
    val eventsByDate = plannedList
        .filter { it.plannedDate.isNotBlank() }
        .groupBy {
            LocalDate.parse(it.plannedDate, formatter)
        }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        Box {
            RedTopBar(
                title = "Planlanan Bakımlar",
                showMenu = false
            )

            // Sağ üst köşeye sabitlenmiş + butonu
            IconButton(
                onClick = {
                    navController.navigate("ocrScan")
                },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 8.dp, end = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Yeni Plan Ekle",
                    tint = Color.White
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        CalendarWithEvents(
            eventsByDate = eventsByDate,
            onDateClick = { selectedDate ->
                val formatted = selectedDate.format(formatter)
                val dailyList = plannedList.filter { it.plannedDate == formatted }
                val encodedList = Uri.encode(Gson().toJson(dailyList))
                navController.navigate("dailyMaintenances/$formatted/$encodedList")
            }
        )


        Spacer(Modifier.height(12.dp))

        selectedDate?.let { date ->
            val formatted = date.format(formatter)
            val dailyList = plannedList.filter { it.plannedDate == formatted }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                item {
                    Text(
                        text = "📅 $formatted tarihindeki bakımlar:",
                        color = White,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                items(dailyList) { maintenance ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = CardDark)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Makine: ${maintenance.machineName}", color = White)
                            Text("Açıklama: ${maintenance.description}", color = White)
                            Text("Not: ${maintenance.note}", color = White)
                            Text("Malzeme Sayısı: ${maintenance.parts.size}", color = White)
                            Spacer(Modifier.height(4.dp))
                            Button(
                                onClick = {},
                                enabled = false,
                                colors = ButtonDefaults.buttonColors(containerColor = Gray)
                            ) {
                                Text("Bakımı Bitir (Pasif)", color = White)
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun CalendarWithEvents(
    eventsByDate: Map<LocalDate, List<Maintenance>>,
    onDateClick: (LocalDate) -> Unit
) {
    val months = remember {
        CalendarHelper.generateMonthRange(
            centerMonth = CalendarHelper.currentMonth(),
            past = 12,
            future = 12
        )
    }

    val today = CalendarHelper.today()
    var selectedDate by remember { mutableStateOf(today) }
    val listState: LazyListState = rememberLazyListState()
    val todayMonthIndex = months.indexOf(CalendarHelper.currentMonth())
    val context = LocalContext.current

    var openDatePicker by remember { mutableStateOf(false) }
    var scrollTargetIndex by remember { mutableStateOf<Int?>(todayMonthIndex) }

    // İlk açılışta bugüne scroll
    LaunchedEffect(scrollTargetIndex) {
        scrollTargetIndex?.let {
            listState.scrollToItem(it)
            scrollTargetIndex = null
        }
    }

    if (openDatePicker) {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val pickedDate = LocalDate.of(year, month + 1, dayOfMonth)
                selectedDate = pickedDate
                onDateClick(pickedDate)
                val index = months.indexOf(YearMonth.from(pickedDate))
                if (index != -1) scrollTargetIndex = index
                openDatePicker = false
            },
            today.year,
            today.monthValue - 1,
            today.dayOfMonth
        ).show()
    }

    Column(modifier = Modifier.fillMaxWidth()) {

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            state = listState
        ) {
            items(months) { month ->
                CalendarMonthView(
                    month = month,
                    selectedDate = selectedDate,
                    events = eventsByDate,
                    onDateSelected = {
                        selectedDate = it
                        onDateClick(it)
                    }
                )
            }
        }
    }
}
