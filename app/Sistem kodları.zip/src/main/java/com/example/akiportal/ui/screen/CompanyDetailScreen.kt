package com.example.akiportal.ui.screen

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.akiportal.model.Company
import com.example.akiportal.model.Machine
import com.example.akiportal.ui.components.AddMachineDialog
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.ui.theme.BackgroundDark
import com.example.akiportal.ui.theme.White
import com.example.akiportal.viewmodel.MachineViewModel
import com.example.akiportal.viewmodel.MaterialViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.gson.Gson
import android.content.Context
import com.example.akiportal.util.PermissionManager
import com.example.akiportal.util.PermissionType
import com.example.akiportal.ui.theme.RedPrimary
import kotlinx.coroutines.launch
import com.example.akiportal.ui.components.LocationPickerScreen


@Composable
fun CompanyDetailScreen(
    company: Company,
    navController: NavHostController,
    machineViewModel: MachineViewModel = viewModel(),
    materialViewModel: MaterialViewModel = viewModel()
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var machines by remember { mutableStateOf<List<Machine>>(emptyList()) }
    var showAddMachineDialog by remember { mutableStateOf(false) }
    var showEditCompanyDialog by remember { mutableStateOf(false) }
    var showDeleteMachineDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        machineViewModel.loadMachines(company.id)
        machineViewModel.machines.collect { machines = it }
    }

    Column(Modifier.fillMaxSize().background(BackgroundDark)) {
        RedTopBar(title = company.name, showMenu = true) {
            DropdownMenuItem(
                text = { Text("Şirketi Düzenle") },
                onClick = {
                    if (PermissionManager.hasPermission(PermissionType.COMPANY_ADD)) {
                        showEditCompanyDialog = true
                    } else {
                        scope.launch { snackbarHostState.showSnackbar("Şirket düzenleme yetkiniz yok.") }
                    }
                }
            )
            DropdownMenuItem(
                text = { Text("Makine Sil") },
                onClick = {
                    if (PermissionManager.hasPermission(PermissionType.MACHINE_DELETE)) {
                        showDeleteMachineDialog = true
                    } else {
                        scope.launch { snackbarHostState.showSnackbar("Makine silme yetkiniz yok.") }
                    }
                }
            )
        }

        CompanyInfoCard(company, context)

        Button(
            onClick = {
                if (PermissionManager.hasPermission(PermissionType.MACHINE_ADD)) {
                    showAddMachineDialog = true
                } else {
                    scope.launch { snackbarHostState.showSnackbar("Makine ekleme yetkiniz yok.") }
                }
            },
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = RedPrimary) // ⬅ burası eklendi
        ) {
            Text("Makine Ekle", color = White)
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text("Makineler", color = Color.White, modifier = Modifier.padding(start = 16.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(machines) { machine ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val json = Uri.encode(Gson().toJson(machine))
                            navController.navigate("machineDetail/$json")
                        },
                    colors = CardDefaults.cardColors(containerColor = Color.DarkGray)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Ad: ${machine.name}", color = Color.White)
                        Text("Seri No: ${machine.serialNumber}", color = Color.White)
                    }
                }
            }
        }

        if (showAddMachineDialog) {
            AddMachineDialog(
                companyId = company.id,
                onDismiss = {
                    showAddMachineDialog = false
                    machineViewModel.loadMachines(company.id)
                },
                materialViewModel = materialViewModel
            )
        }

        if (showEditCompanyDialog) {
            CompanyEditDialog(company = company, onDismiss = { showEditCompanyDialog = false }) {
                showEditCompanyDialog = false
            }
        }

        if (showDeleteMachineDialog) {
            DeleteMachinesDialog(
                machines = machines,
                companyId = company.id,
                onDismiss = { showDeleteMachineDialog = false },
                onMachinesDeleted = {
                    machineViewModel.loadMachines(company.id)
                }
            )
        }
    }

    SnackbarHost(hostState = snackbarHostState)
}

@Composable
fun CompanyInfoCard(company: Company, context: Context) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Yetkili: ${company.contactPerson}", fontSize = 16.sp, color = Color.Black)
            Text("Görevi: ${company.role.orEmpty()}", fontSize = 14.sp, color = Color.DarkGray)

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Phone, contentDescription = "Telefon", tint = Color.Gray)
                Spacer(modifier = Modifier.width(4.dp))
                Text(company.contactNumber ?: "-", fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = "Konum", tint = Color.Gray)
                Spacer(modifier = Modifier.width(4.dp))
                Text(company.location ?: "-", fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text("Şirket Notu:", fontSize = 14.sp, color = Color.Black)
            Text(company.note ?: "-", fontSize = 14.sp)

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                OutlinedButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${company.location}"))
                        intent.setPackage("com.google.android.apps.maps")
                        context.startActivity(intent)
                    }
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = RedPrimary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Haritada Göster", color = RedPrimary)
                }

                OutlinedButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL).apply {
                            data = Uri.parse("tel:${company.contactNumber}")
                        }
                        context.startActivity(intent)
                    }
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, tint = RedPrimary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ara", color = RedPrimary)
                }
            }

        }
    }
}

@Composable
fun CompanyEditDialog(
    company: Company,
    onDismiss: () -> Unit,
    onSave: () -> Unit
) {
    var name by remember { mutableStateOf(company.name) }
    var contactPerson by remember { mutableStateOf(company.contactPerson) }
    var contactNumber by remember { mutableStateOf(company.contactNumber) }
    var location by remember { mutableStateOf(company.location ?: "") }
    var note by remember { mutableStateOf(company.note) }
    var role by remember { mutableStateOf(company.role ?: "") }

    var showMap by remember { mutableStateOf(false) }

    if (showMap) {
        LocationPickerScreen(
            onLocationSelected = { latLng, address ->
                location = address
                showMap = false
            }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                FirebaseFirestore.getInstance()
                    .collection("companies")
                    .document(company.id)
                    .update(
                        mapOf(
                            "name" to name,
                            "contactPerson" to contactPerson,
                            "contactNumber" to contactNumber,
                            "location" to location,
                            "note" to note,
                            "role" to role
                        )
                    )
                    .addOnSuccessListener { onSave() }
            }) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        },
        title = { Text("Şirket Bilgilerini Düzenle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Şirket Adı") })
                OutlinedTextField(value = contactPerson, onValueChange = { contactPerson = it }, label = { Text("Yetkili") })
                OutlinedTextField(value = contactNumber, onValueChange = { contactNumber = it }, label = { Text("Telefon") })

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Konum") },
                    trailingIcon = {
                        IconButton(onClick = { showMap = true }) {
                            Icon(Icons.Default.LocationOn, contentDescription = "Haritadan Seç", tint = RedPrimary)
                        }
                    }
                )

                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Not") })
                OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Görevi") })
            }
        }
    )
}


@Composable
fun DeleteMachinesDialog(
    machines: List<Machine>,
    companyId: String,
    onDismiss: () -> Unit,
    onMachinesDeleted: () -> Unit
) {
    var selectedMachines by remember { mutableStateOf(setOf<String>()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val db = FirebaseFirestore.getInstance()
                selectedMachines.forEach { machineId ->
                    db.collection("machines").document(machineId).delete()
                }
                onDismiss()
                onMachinesDeleted()
            }) {
                Text("Seçilenleri Sil")
            }
        },
        dismissButton = {
            TextButton(onClick = {
                selectedMachines = emptySet()
                onDismiss()
            }) { Text("İptal") }
        },
        title = { Text("Makine Sil") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Silmek istediğiniz makineleri seçin:")
                machines.forEach { machine ->
                    val isSelected = selectedMachines.contains(machine.id)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedMachines = if (isSelected)
                                    selectedMachines - machine.id
                                else
                                    selectedMachines + machine.id
                            }
                            .background(if (isSelected) Color.LightGray else Color.Transparent)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(machine.name)
                        Text(machine.serialNumber)
                    }
                }
            }
        }
    )
}
