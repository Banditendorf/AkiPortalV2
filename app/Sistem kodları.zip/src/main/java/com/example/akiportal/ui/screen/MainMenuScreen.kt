package com.example.akiportal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.akiportal.model.User
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.ui.theme.*
import com.example.akiportal.util.PermissionManager
import com.example.akiportal.util.PermissionType
import kotlinx.coroutines.launch

data class MenuItem(
    val title: String,
    val route: String,
    val icon: ImageVector,
    val permission: PermissionType? = null
)

@Composable
fun MainMenuScreen(
    currentUser: User,
    onMenuItemClick: (String) -> Unit,
    onNotificationClick: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val menuItems = listOf(
        MenuItem("Şirketler", "companies", Icons.Default.Business, PermissionType.COMPANY_ADD),
        MenuItem("Planlanan Bakımlar", "bakimlar", Icons.Default.CalendarToday, PermissionType.MAINTENANCE_ADD),
        MenuItem("Hazırlanacak Malzemeler", "hazirliklar", Icons.Default.ListAlt, PermissionType.MAINTENANCE_ADD),
        MenuItem("Malzeme Listesi", "malzemeler", Icons.Default.Build, PermissionType.MATERIAL_ADD),
        MenuItem("Kullanıcılar", "kullanicilar", Icons.Default.People, PermissionType.USER_ADD),
        MenuItem("Ayarlar", "ayarlar", Icons.Default.Settings) // permission null = herkese açık
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        RedTopBar(title = currentUser.fullName)

        Spacer(modifier = Modifier.height(6.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .weight(0.75f)
                .padding(horizontal = 12.dp)
        ) {
            items(menuItems) { item ->
                Card(
                    onClick = {
                        if (item.permission == null || PermissionManager.hasPermission(item.permission)) {
                            onMenuItemClick(item.route)
                        } else {
                            scope.launch {
                                snackbarHostState.showSnackbar("Bu işlem için yetkiniz yok.")
                            }
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = RedPrimary),
                    elevation = CardDefaults.cardElevation(4.dp),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = White,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = item.title,
                            fontSize = 14.sp,
                            color = White,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // 🔔 Bildirim kutusu — tıklanabilir alan
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.25f)
                .background(DarkGray)
                .padding(12.dp)
                .clickable { onNotificationClick() } // 👈 burada bağlandı
        ) {
            Divider(color = BackgroundDark, thickness = 1.dp)
            Text(
                text = "Bildirimler",
                fontSize = 14.sp,
                color = White,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
            Text(
                text = "• Yeni bakım planlandı\n• 2 makinenin servisi yaklaşıyor",
                fontSize = 13.sp,
                color = LightGray
            )
        }

        SnackbarHost(hostState = snackbarHostState)
    }
}
