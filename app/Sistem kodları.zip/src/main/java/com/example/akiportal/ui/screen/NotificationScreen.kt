package com.example.akiportal.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.ui.theme.*



data class NotificationItem(
    val id: String,
    val message: String,
    val type: NotificationType,
    val timestamp: String
)

enum class NotificationType {
    WARNING, INFO, SUCCESS
}

@Composable
fun NotificationScreen() {
    val notifications = remember {
        listOf(
            NotificationItem("1", "Kaeser KX90 bakım zamanı geldi!", NotificationType.WARNING, "14.04.2025 - 08:00"),
            NotificationItem("2", "Yeni bir bakım planlandı (Atlas Copco)", NotificationType.INFO, "13.04.2025 - 16:30"),
            NotificationItem("3", "Kaeser KX90 malzemeleri hazırlandı.", NotificationType.SUCCESS, "13.04.2025 - 14:00")
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        RedTopBar(title = "Bildirim Geçmişi")

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(notifications) { notification ->
                NotificationCard(notification)
            }
        }
    }
}

@Composable
fun NotificationCard(item: NotificationItem) {
    val icon: ImageVector
    val iconColor: androidx.compose.ui.graphics.Color

    when (item.type) {
        NotificationType.WARNING -> {
            icon = Icons.Default.Warning
            iconColor = RedPrimary
        }
        NotificationType.INFO -> {
            icon = Icons.Default.Notifications
            iconColor = BluePrimary
        }
        NotificationType.SUCCESS -> {
            icon = Icons.Default.CheckCircle
            iconColor = GreenPrimary
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardDark)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(item.message, color = White, style = MaterialTheme.typography.bodyMedium)
                Text(item.timestamp, color = LightGray, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
