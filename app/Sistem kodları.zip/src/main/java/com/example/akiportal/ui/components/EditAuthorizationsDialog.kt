package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.UserPermissions

@Composable
fun EditAuthorizationsDialog(
    initialAuthorizations: UserPermissions,
    onDismiss: () -> Unit,
    onSave: (UserPermissions) -> Unit
) {
    var authorizations by remember { mutableStateOf(initialAuthorizations) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yetkileri Düzenle") },
        confirmButton = {
            TextButton(onClick = { onSave(authorizations) }) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PermissionSwitch("Tüm Yetkiler", authorizations.fullAccess) {
                    authorizations = if (it) {
                        UserPermissions(
                            fullAccess = true,
                            addCompany = true,
                            deleteCompany = true,
                            addMachine = true,
                            deleteMachine = true,
                            addMaintenance = true,
                            deleteMaintenance = true,
                            addCompanyNote = true,
                            addMachineNote = true,
                            addMaintenanceNote = true,
                            addUser = true,
                            deleteUser = true,
                            editUserRoles = true,
                            addMaterial = true,
                            deleteMaterial = true,
                            addCategory = true,
                            deleteCategory = true,
                            stockControl = true,
                            updateMachine = true,
                            viewLogs = true
                        )
                    } else {
                        UserPermissions()
                    }
                }

                Divider()

                PermissionSwitch("Şirket Ekle", authorizations.addCompany) {
                    authorizations = authorizations.copy(addCompany = it)
                }
                PermissionSwitch("Şirket Sil", authorizations.deleteCompany) {
                    authorizations = authorizations.copy(deleteCompany = it)
                }
                PermissionSwitch("Makine Ekle", authorizations.addMachine) {
                    authorizations = authorizations.copy(addMachine = it)
                }
                PermissionSwitch("Makine Sil", authorizations.deleteMachine) {
                    authorizations = authorizations.copy(deleteMachine = it)
                }
                PermissionSwitch("Makine Güncelle", authorizations.updateMachine) {
                    authorizations = authorizations.copy(updateMachine = it)
                }

                PermissionSwitch("Bakım Planlama", authorizations.addMaintenance) {
                    authorizations = authorizations.copy(addMaintenance = it)
                }
                PermissionSwitch("Bakım Sil", authorizations.deleteMaintenance) {
                    authorizations = authorizations.copy(deleteMaintenance = it)
                }

                Divider()

                PermissionSwitch("Şirket Notu Ekle", authorizations.addCompanyNote) {
                    authorizations = authorizations.copy(addCompanyNote = it)
                }
                PermissionSwitch("Makine Notu Ekle", authorizations.addMachineNote) {
                    authorizations = authorizations.copy(addMachineNote = it)
                }
                PermissionSwitch("Bakım Notu Ekle", authorizations.addMaintenanceNote) {
                    authorizations = authorizations.copy(addMaintenanceNote = it)
                }

                Divider()

                PermissionSwitch("Kullanıcı Ekle", authorizations.addUser) {
                    authorizations = authorizations.copy(addUser = it)
                }
                PermissionSwitch("Kullanıcı Sil", authorizations.deleteUser) {
                    authorizations = authorizations.copy(deleteUser = it)
                }
                PermissionSwitch("Yetkilendirme", authorizations.editUserRoles) {
                    authorizations = authorizations.copy(editUserRoles = it)
                }

                Divider()

                PermissionSwitch("Malzeme Ekle", authorizations.addMaterial) {
                    authorizations = authorizations.copy(addMaterial = it)
                }
                PermissionSwitch("Malzeme Sil", authorizations.deleteMaterial) {
                    authorizations = authorizations.copy(deleteMaterial = it)
                }
                PermissionSwitch("Kategori Ekle", authorizations.addCategory) {
                    authorizations = authorizations.copy(addCategory = it)
                }
                PermissionSwitch("Kategori Sil", authorizations.deleteCategory) {
                    authorizations = authorizations.copy(deleteCategory = it)
                }

                Divider()

                PermissionSwitch("Stok Yönetimi", authorizations.stockControl) {
                    authorizations = authorizations.copy(stockControl = it)
                }

                PermissionSwitch("Logları Görüntüleme", authorizations.viewLogs) {
                    authorizations = authorizations.copy(viewLogs = it)
                }
            }
        }
    )
}

@Composable
fun PermissionSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
