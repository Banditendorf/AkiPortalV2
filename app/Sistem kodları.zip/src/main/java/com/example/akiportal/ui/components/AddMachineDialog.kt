package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.Machine
import com.example.akiportal.viewmodel.MaterialViewModel
import com.google.firebase.firestore.FirebaseFirestore
import androidx.compose.ui.Alignment
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMachineDialog(
    companyId: String,
    onDismiss: () -> Unit,
    materialViewModel: MaterialViewModel
) {
    val db = FirebaseFirestore.getInstance()

    var name by remember { mutableStateOf("") }
    var serial by remember { mutableStateOf("") }
    var oilCode by remember { mutableStateOf("") }
    var oilLiter by remember { mutableStateOf("") }
    var estimatedHours by remember { mutableStateOf("") }


    val panelFilterOptions = listOf("Küçük", "Orta", "Büyük", "Yok")
    var selectedPanelFilter by remember { mutableStateOf(panelFilterOptions.first()) }
    var panelExpanded by remember { mutableStateOf(false) }

    val filterStates = remember {
        mutableStateMapOf(
            "Hava Filtresi" to mutableStateOf(Pair("", 1)),
            "Yağ Filtresi" to mutableStateOf(Pair("", 1)),
            "Separatör" to mutableStateOf(Pair("", 1)),
            "Kurutucu Filtresi" to mutableStateOf(Pair("", 1))
        )
    }

    val allCodes by materialViewModel.materials.collectAsState()
    val expandedFilter = remember { mutableStateMapOf<String, Boolean>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val machine = Machine(
                    companyId = companyId,
                    name = name,
                    serialNumber = serial,
                    note = "",

                    airFilterCode = filterStates["Hava Filtresi"]?.value?.first ?: "",
                    airFilterCount = filterStates["Hava Filtresi"]?.value?.second ?: 0,
                    oilFilterCode = filterStates["Yağ Filtresi"]?.value?.first ?: "",
                    oilFilterCount = filterStates["Yağ Filtresi"]?.value?.second ?: 0,
                    separatorCode = filterStates["Separatör"]?.value?.first ?: "",
                    separatorCount = filterStates["Separatör"]?.value?.second ?: 0,
                    dryerFilterCode = filterStates["Kurutucu Filtresi"]?.value?.first ?: "",
                    dryerFilterCount = filterStates["Kurutucu Filtresi"]?.value?.second ?: 0,

                    panelFilterSize = selectedPanelFilter,
                    oilCode = oilCode,
                    oilLiter = oilLiter.toDoubleOrNull() ?: 0.0,

                    estimatedHours = estimatedHours.toIntOrNull() ?: 0,
                    nextMaintenanceHour = estimatedHours.toIntOrNull() ?: 0 // ✅ EKLENDİ
                )

                db.collection("machines").add(machine).addOnSuccessListener { onDismiss() }
            }) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        },
        title = { Text("Yeni Makine Ekle") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Makine Adı") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = serial,
                    onValueChange = { serial = it },
                    label = { Text("Seri No") },
                    modifier = Modifier.fillMaxWidth()
                )

                Divider()

                filterStates.forEach { (label, state) ->
                    val selectedCode = state.value.first
                    val quantity = state.value.second
                    val isExpanded = expandedFilter[label] ?: false

                    Text(label, style = MaterialTheme.typography.labelLarge)

                    ExposedDropdownMenuBox(
                        expanded = isExpanded,
                        onExpandedChange = { expandedFilter[label] = !isExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedCode,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Kod Seç") },
                            trailingIcon = {
                                Icon(
                                    if (isExpanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                    contentDescription = null
                                )
                            },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )

                        ExposedDropdownMenu(
                            expanded = isExpanded,
                            onDismissRequest = { expandedFilter[label] = false }
                        ) {
                            allCodes.map { it.code }.distinct().forEach { code ->
                                DropdownMenuItem(
                                    text = { Text(code) },
                                    onClick = {
                                        state.value = Pair(code, quantity)
                                        expandedFilter[label] = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text("Adet: ", modifier = Modifier.align(Alignment.CenterVertically))

                        Button(
                            onClick = {
                                state.value = Pair(selectedCode, (quantity - 1).coerceAtLeast(1))
                            },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(32.dp)
                        ) { Text("-") }

                        Text(
                            quantity.toString(),
                            modifier = Modifier
                                .padding(horizontal = 8.dp)
                                .align(Alignment.CenterVertically)
                        )

                        Button(
                            onClick = {
                                state.value = Pair(selectedCode, quantity + 1)
                            },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(32.dp)
                        ) { Text("+") }
                    }
                }

                Text("Panel Filtresi", style = MaterialTheme.typography.labelLarge)
                ExposedDropdownMenuBox(
                    expanded = panelExpanded,
                    onExpandedChange = { panelExpanded = !panelExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedPanelFilter,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Panel Tipi") },
                        trailingIcon = {
                            Icon(
                                if (panelExpanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                contentDescription = null
                            )
                        },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )

                    ExposedDropdownMenu(
                        expanded = panelExpanded,
                        onDismissRequest = { panelExpanded = false }
                    ) {
                        panelFilterOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    selectedPanelFilter = option
                                    panelExpanded = false
                                }
                            )
                        }
                    }
                }

                Divider()

                Text("Yağ Bilgisi", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = oilCode,
                        onValueChange = { oilCode = it },
                        label = { Text("Yağ Kodu") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = oilLiter,
                        onValueChange = { oilLiter = it },
                        label = { Text("Litre") },
                        modifier = Modifier.width(100.dp)
                    )
                }

                OutlinedTextField(
                    value = estimatedHours,
                    onValueChange = { estimatedHours = it },
                    label = { Text("Tahmini Makine Saati") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    )
}
