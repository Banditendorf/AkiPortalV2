package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.Material

@Composable
fun MaterialDetailDialog(
    material: Material,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Malzeme Detayı") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Kod: ${material.code}")
                Text("Marka: ${material.brand}")
                Text("Raf: ${material.shelf}")
                Text("Stok: ${material.stock}")
                Text("Kritik Stok: ${material.kritikStok}")
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = onEdit) { Text("Düzenle") }
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = onDelete) { Text("Sil") }
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = onDismiss) { Text("Kapat") }
            }
        },
        dismissButton = {}
    )
}
