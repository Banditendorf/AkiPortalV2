package com.example.akiportal.util

import android.content.Context
import android.widget.Toast
import com.example.akiportal.model.UserPermissions

object PermissionManager {

    private var permissions: UserPermissions? = null

    fun setPermissions(userPermissions: UserPermissions) {
        permissions = userPermissions
    }

    fun clearPermissions() {
        permissions = null
    }

    fun hasPermission(type: PermissionType): Boolean {
        val p = permissions ?: return false
        return when (type) {
            PermissionType.ALL -> p.fullAccess
            PermissionType.COMPANY_ADD -> p.addCompany
            PermissionType.COMPANY_DELETE -> p.deleteCompany
            PermissionType.MACHINE_ADD -> p.addMachine
            PermissionType.MACHINE_DELETE -> p.deleteMachine
            PermissionType.MACHINE_UPDATE -> p.updateMachine
            PermissionType.MAINTENANCE_ADD -> p.addMaintenance
            PermissionType.MAINTENANCE_DELETE -> p.deleteMaintenance
            PermissionType.COMPANY_NOTE -> p.addCompanyNote
            PermissionType.MACHINE_NOTE -> p.addMachineNote
            PermissionType.MAINTENANCE_NOTE -> p.addMaintenanceNote
            PermissionType.USER_ADD -> p.addUser
            PermissionType.USER_DELETE -> p.deleteUser
            PermissionType.USER_AUTH -> p.editUserRoles
            PermissionType.MATERIAL_ADD -> p.addMaterial
            PermissionType.MATERIAL_DELETE -> p.deleteMaterial
            PermissionType.CATEGORY_ADD -> p.addCategory
            PermissionType.CATEGORY_DELETE -> p.deleteCategory
            PermissionType.STOCK_MANAGEMENT -> p.stockControl
            PermissionType.LOG_VIEW -> p.viewLogs
        }
    }


    fun showNoPermissionMessage(context: Context) {
        Toast.makeText(context, "Bu işlem için yetkiniz yok.", Toast.LENGTH_SHORT).show()
    }
}

enum class PermissionType {
    ALL,
    COMPANY_ADD,
    COMPANY_DELETE,
    MACHINE_ADD,
    MACHINE_DELETE,
    MACHINE_UPDATE,
    MAINTENANCE_ADD,
    MAINTENANCE_DELETE,
    COMPANY_NOTE,
    MACHINE_NOTE,
    MAINTENANCE_NOTE,
    USER_ADD,
    USER_DELETE,
    USER_AUTH,
    MATERIAL_ADD,
    MATERIAL_DELETE,
    CATEGORY_ADD,
    CATEGORY_DELETE,
    STOCK_MANAGEMENT,
    LOG_VIEW

}

