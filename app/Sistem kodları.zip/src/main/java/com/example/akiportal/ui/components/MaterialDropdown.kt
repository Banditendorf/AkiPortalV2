package com.example.akiportal.ui.components

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.akiportal.viewmodel.MaterialViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaterialDropdown(
    label: String,
    selectedMaterial: String,
    onMaterialSelected: (String) -> Unit,
    viewModel: MaterialViewModel = viewModel()
) {
    val materials by viewModel.materials.collectAsState()
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selectedMaterial,
            onValueChange = {},
            label = { Text(label) },
            readOnly = true,
            modifier = Modifier.menuAnchor()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            materials.forEach {
                DropdownMenuItem(
                    text = { Text(it.code) }, // name → code
                    onClick = {
                        onMaterialSelected(it.code)
                        expanded = false
                    }
                )
            }
        }
    }
}
