package com.example.akiportal.viewmodel

import androidx.lifecycle.ViewModel
import com.example.akiportal.model.Company
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class CompanyViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()

    private val _companies = MutableStateFlow<List<Company>>(emptyList())
    val companies: StateFlow<List<Company>> = _companies

    fun loadCompanies() {
        db.collection("companies").get().addOnSuccessListener { snapshot ->
            val list = snapshot.documents.mapNotNull { doc ->
                doc.toObject(Company::class.java)
            }
            _companies.value = list
        }
    }
    fun updateCompany(company: Company) {
        db.collection("companies").document(company.id).set(company)
            .addOnSuccessListener { loadCompanies() }
    }
//    fun insertSampleCompanies() {
//        val sampleCompanies = listOf(
//            Company(
//                name = "Dalgakıran Kompresör Denizli",
//                contactPerson = "Mehmet Korkmaz",
//                contactNumber = "5321112233",
//                location = "Denizli 2. Organize Sanayi Bölgesi, 20100 Merkezefendi/Denizli",
//                role = "Distribütör",
//                note = "Denizli bölgesi ana bayi."
//            ),
//            Company(
//                name = "Er-Bakır Elektrolitik Bakır Mamulleri A.Ş.",
//                contactPerson = "Ayşe Türkmen",
//                contactNumber = "5324445566",
//                location = "Denizli Organize Sanayi Bölgesi, 20100 Honaz/Denizli",
//                role = "Müşteri",
//                note = "Yıllık bakım anlaşmalı."
//            ),
//            Company(
//                name = "Abalıoğlu Lezita Denizli Şubesi",
//                contactPerson = "Onur Demirtaş",
//                contactNumber = "5389876543",
//                location = "Kazım Karabekir Mah. 1435 Sk. No:10, Pamukkale/Denizli",
//                role = "Müşteri",
//                note = "Gıda üretim tesisi."
//            ),
//            Company(
//                name = "Kardem Tekstil",
//                contactPerson = "Zeynep Yıldız",
//                contactNumber = "5311122334",
//                location = "Denizli 1. OSB, Sümer Mah. 20860 Merkezefendi/Denizli",
//                role = "Bakımcı",
//                note = "Tekstil üretimi yapıyor."
//            ),
//            Company(
//                name = "Efor Endüstri",
//                contactPerson = "Ali İhsan Aksoy",
//                contactNumber = "5340001122",
//                location = "Sarayköy Organize Sanayi Bölgesi, Sarayköy/Denizli",
//                role = "Servis",
//                note = "Makine tedarikçisi."
//            ),
//            Company(
//                name = "Desa Deri Denizli Üretim",
//                contactPerson = "Elif Şahin",
//                contactNumber = "5339988776",
//                location = "Denizli OSB, 3. Cadde No:24, Honaz/Denizli",
//                role = "Müşteri",
//                note = "Deri konfeksiyon fabrikası."
//            ),
//            Company(
//                name = "Yeşim Tekstil Denizli",
//                contactPerson = "Cem Kılıç",
//                contactNumber = "5361234567",
//                location = "Denizli OSB, 2. Kısım, Merkezefendi/Denizli",
//                role = "Bakımcı",
//                note = "İhracat yapan tekstil fabrikası."
//            ),
//            Company(
//                name = "Denizli Cam Sanayi",
//                contactPerson = "Burcu Erdem",
//                contactNumber = "5301122334",
//                location = "İncilipınar Mah. 1205 Sok. No:8, Pamukkale/Denizli",
//                role = "Servis",
//                note = "Isıcam üretimi yapılıyor."
//            ),
//            Company(
//                name = "Aselsis Elektrik",
//                contactPerson = "Fatih Karaca",
//                contactNumber = "5351122112",
//                location = "İzmir Bulvarı No:135, Pamukkale/Denizli",
//                role = "Distribütör",
//                note = "Otomasyon ekipmanı satıcısı."
//            ),
//            Company(
//                name = "Uğurlu Makine Sanayi",
//                contactPerson = "Gökçe Demir",
//                contactNumber = "5312233445",
//                location = "Denizli OSB 4. Cadde No:3, Honaz/Denizli",
//                role = "Müşteri",
//                note = "Makine parkurunu genişletiyor."
//            )
//        )
//
//        val db = FirebaseFirestore.getInstance()
//        sampleCompanies.forEach {
//            db.collection("companies").add(it)
//        }
//    }


}
