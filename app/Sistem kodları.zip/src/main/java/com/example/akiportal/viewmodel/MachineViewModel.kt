package com.example.akiportal.viewmodel

import androidx.lifecycle.ViewModel
import com.example.akiportal.model.Machine
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.*

class MachineViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()

    private val _machines = MutableStateFlow<List<Machine>>(emptyList())
    val machines: StateFlow<List<Machine>> = _machines

    // Şirket bazlı makineleri yükle
    fun loadMachines(companyId: String) {
        db.collection("machines")
            .whereEqualTo("companyId", companyId)
            .get()
            .addOnSuccessListener { result ->
                val list = result.documents.mapNotNull { doc ->
                    doc.toObject(Machine::class.java)?.copy(id = doc.id)
                }

                _machines.value = list
            }
            .addOnFailureListener {
                _machines.value = emptyList()
            }
    }

    // Yeni makine ekle
    fun addMachine(machine: Machine, onComplete: () -> Unit) {
        db.collection("machines")
            .add(machine)
            .addOnSuccessListener { onComplete() }
            .addOnFailureListener { onComplete() }
    }

    // Makine güncelle
    fun updateMachine(machine: Machine, onComplete: () -> Unit) {
        val id = machine.id.ifEmpty { return }
        db.collection("machines").document(id)
            .set(machine)
            .addOnSuccessListener { onComplete() }
            .addOnFailureListener { onComplete() }
    }

    // Makine sil
    fun deleteMachine(machineId: String, onComplete: () -> Unit) {
        db.collection("machines").document(machineId)
            .delete()
            .addOnSuccessListener { onComplete() }
            .addOnFailureListener { onComplete() }
    }

    // Tüm makinelerin estimatedHours değerini +24 arttır
    fun incrementDailyMachineHours() {
        db.collection("machines").get()
            .addOnSuccessListener { result ->
                for (doc in result.documents) {
                    val machine = doc.toObject(Machine::class.java)
                    machine?.let {
                        val newHours = it.estimatedHours + 24
                        db.collection("machines").document(doc.id)
                            .update("estimatedHours", newHours)
                    }
                }
            }
    }

    // Yaklaşan bakım gereken makineleri getir
    fun checkUpcomingMaintenances(
        threshold: Int = 48, // kaç saat kala haber verilsin?
        onResult: (List<Machine>) -> Unit
    ) {
        db.collection("machines").get()
            .addOnSuccessListener { result ->
                val approaching = result.documents.mapNotNull { doc ->
                    val machine = doc.toObject(Machine::class.java)
                    machine?.let {
                        if (it.nextMaintenanceHour - it.estimatedHours <= threshold) {
                            it.copy(id = doc.id)
                        } else null
                    }
                }
                onResult(approaching)
            }
            .addOnFailureListener {
                onResult(emptyList())
            }
    }
}
