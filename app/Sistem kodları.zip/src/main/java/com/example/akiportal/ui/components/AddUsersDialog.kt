package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.akiportal.model.UserPermissions
import com.example.akiportal.viewmodel.UserViewModel
import androidx.compose.ui.Alignment


@Composable
fun AddUsersDialog(
    onDismiss: () -> Unit,
    userViewModel: UserViewModel = viewModel()
) {
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("") }
    var workPhone by remember { mutableStateOf("") }
    var personalPhone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var permissions by remember { mutableStateOf(UserPermissions()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yeni Kullanıcı Ekle") },
        confirmButton = {
            TextButton(onClick = {
                if (!email.endsWith("@akiendüstri.com")) {
                    error = "E-posta @akiendüstri.com ile bitmeli"
                    return@TextButton
                }
                if (password.length < 6) {
                    error = "Şifre en az 6 karakter olmalı"
                    return@TextButton
                }

                userViewModel.createUserWithAuth(
                    email = email,
                    password = password,
                    fullName = fullName,
                    isActive = true,
                    workPhone = workPhone,
                    personalPhone = personalPhone,
                    permissions = permissions,
                    onError = { error = it },
                    onSuccess = { onDismiss() }
                )
            }) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Ad Soyad") })
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("E-posta") })
                OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Görevi") })
                OutlinedTextField(value = workPhone, onValueChange = { workPhone = it }, label = { Text("İş Telefonu") })
                OutlinedTextField(value = personalPhone, onValueChange = { personalPhone = it }, label = { Text("Kişisel Telefon") })
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Şifre") },
                    visualTransformation = PasswordVisualTransformation()
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Yetkiler:")

                CheckboxRow("Tüm Yetkiler", permissions.fullAccess) {
                    permissions = if (it) UserPermissions(fullAccess = true,
                        addCompany = true, deleteCompany = true,
                        addMachine = true, deleteMachine = true,
                        addMaintenance = true, deleteMaintenance = true,
                        addCompanyNote = true, addMachineNote = true, addMaintenanceNote = true,
                        addUser = true, deleteUser = true, editUserRoles = true,
                        addMaterial = true, deleteMaterial = true,
                        addCategory = true, deleteCategory = true,
                        stockControl = true
                    ) else UserPermissions()
                }

                Divider()
                CheckboxRow("Şirket Ekle", permissions.addCompany) { permissions = permissions.copy(addCompany = it) }
                CheckboxRow("Şirket Sil", permissions.deleteCompany) { permissions = permissions.copy(deleteCompany = it) }
                CheckboxRow("Makine Ekle", permissions.addMachine) { permissions = permissions.copy(addMachine = it) }
                CheckboxRow("Makine Sil", permissions.deleteMachine) { permissions = permissions.copy(deleteMachine = it) }
                CheckboxRow("Bakım Planlama", permissions.addMaintenance) { permissions = permissions.copy(addMaintenance = it) }
                CheckboxRow("Bakım Sil", permissions.deleteMaintenance) { permissions = permissions.copy(deleteMaintenance = it) }

                Divider()
                CheckboxRow("Şirket Notu Ekle", permissions.addCompanyNote) { permissions = permissions.copy(addCompanyNote = it) }
                CheckboxRow("Makine Notu Ekle", permissions.addMachineNote) { permissions = permissions.copy(addMachineNote = it) }
                CheckboxRow("Bakım Notu Ekle", permissions.addMaintenanceNote) { permissions = permissions.copy(addMaintenanceNote = it) }

                Divider()
                CheckboxRow("Kullanıcı Ekle", permissions.addUser) { permissions = permissions.copy(addUser = it) }
                CheckboxRow("Kullanıcı Sil", permissions.deleteUser) { permissions = permissions.copy(deleteUser = it) }
                CheckboxRow("Yetkilendirme", permissions.editUserRoles) { permissions = permissions.copy(editUserRoles = it) }

                Divider()
                CheckboxRow("Malzeme Ekle", permissions.addMaterial) { permissions = permissions.copy(addMaterial = it) }
                CheckboxRow("Malzeme Sil", permissions.deleteMaterial) { permissions = permissions.copy(deleteMaterial = it) }
                CheckboxRow("Kategori Ekle", permissions.addCategory) { permissions = permissions.copy(addCategory = it) }
                CheckboxRow("Kategori Sil", permissions.deleteCategory) { permissions = permissions.copy(deleteCategory = it) }

                Divider()
                CheckboxRow("Stok Yönetimi", permissions.stockControl) { permissions = permissions.copy(stockControl = it) }

                error?.let {
                    Text(text = it, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    )
}

@Composable
fun CheckboxRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label)
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
    }
}
