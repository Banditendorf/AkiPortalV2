package com.example.akiportal.ui.components

import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.User

@Composable
fun EditMyProfileDialog(
    initialFullName: String,
    initialWorkPhone: String,
    initialPersonalPhone: String,
    initialRole: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit // fullName, workPhone, personalPhone, role
) {
    var name by remember { mutableStateOf(initialFullName) }
    var workPhone by remember { mutableStateOf(initialWorkPhone) }
    var personalPhone by remember { mutableStateOf(initialPersonalPhone) }
    var role by remember { mutableStateOf(initialRole) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                onSave(name, workPhone, personalPhone, role)
            }) {
                Text("Güncelle")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        },
        title = { Text("Bilgilerini Güncelle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Ad Soyad") })
                OutlinedTextField(value = workPhone, onValueChange = { workPhone = it }, label = { Text("İş Telefonu") })
                OutlinedTextField(value = personalPhone, onValueChange = { personalPhone = it }, label = { Text("Kişisel Telefon") })
                OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Görevi") })
            }
        }
    )
}
