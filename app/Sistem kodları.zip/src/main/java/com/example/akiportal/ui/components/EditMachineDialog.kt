package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.Machine
import com.google.firebase.firestore.FirebaseFirestore

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditMachineDialog(
    machine: Machine,
    onDismiss: () -> Unit,
    onUpdated: () -> Unit
) {
    var name by remember { mutableStateOf(machine.name) }
    var serial by remember { mutableStateOf(machine.serialNumber) }

    var airCode by remember { mutableStateOf(machine.airFilterCode) }
    var airCount by remember { mutableStateOf(machine.airFilterCount.toString()) }

    var oilCode by remember { mutableStateOf(machine.oilFilterCode) }
    var oilCount by remember { mutableStateOf(machine.oilFilterCount.toString()) }

    var sepCode by remember { mutableStateOf(machine.separatorCode) }
    var sepCount by remember { mutableStateOf(machine.separatorCount.toString()) }

    var dryerCode by remember { mutableStateOf(machine.dryerFilterCode) }
    var dryerCount by remember { mutableStateOf(machine.dryerFilterCount.toString()) }

    val panelSizeOptions = listOf("Küçük", "Orta", "Büyük", "Yok")
    var selectedPanelSize by remember { mutableStateOf(machine.panelFilterSize.ifEmpty { panelSizeOptions.first() }) }
    var panelExpanded by remember { mutableStateOf(false) }

    var oilType by remember { mutableStateOf(machine.oilCode) }
    var oilLiter by remember { mutableStateOf(machine.oilLiter.toString()) }

    var estimatedHours by remember { mutableStateOf(machine.estimatedHours.toString()) }

    var note by remember { mutableStateOf(machine.note ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val updatedMap: Map<String, Any> = mapOf(
                    "name" to name,
                    "serialNumber" to serial,
                    "airFilterCode" to airCode,
                    "airFilterCount" to (airCount.toIntOrNull() ?: 0),
                    "oilFilterCode" to oilCode,
                    "oilFilterCount" to (oilCount.toIntOrNull() ?: 0),
                    "separatorCode" to sepCode,
                    "separatorCount" to (sepCount.toIntOrNull() ?: 0),
                    "dryerFilterCode" to dryerCode,
                    "dryerFilterCount" to (dryerCount.toIntOrNull() ?: 0),
                    "panelFilterSize" to selectedPanelSize,
                    "oilCode" to oilType,
                    "oilLiter" to (oilLiter.toDoubleOrNull() ?: 0.0),
                    "estimatedHours" to (estimatedHours.toIntOrNull() ?: 0),
                    "nextMaintenanceHour" to (estimatedHours.toIntOrNull() ?: 0),
                    "note" to note
                )


                FirebaseFirestore.getInstance()
                    .collection("machines")
                    .document(machine.id)
                    .update(updatedMap)
                    .addOnSuccessListener { onUpdated() }
            }) {
                Text("Güncelle")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        },
        title = { Text("Makineyi Güncelle") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Makine Adı") })
                OutlinedTextField(value = serial, onValueChange = { serial = it }, label = { Text("Seri Numarası") })

                FilterEditRow("Hava Filtresi", airCode, airCount) { code, count -> airCode = code; airCount = count }
                FilterEditRow("Yağ Filtresi", oilCode, oilCount) { code, count -> oilCode = code; oilCount = count }
                FilterEditRow("Separatör", sepCode, sepCount) { code, count -> sepCode = code; sepCount = count }
                FilterEditRow("Kurutucu Filtresi", dryerCode, dryerCount) { code, count -> dryerCode = code; dryerCount = count }

                Text("Panel Filtresi", style = MaterialTheme.typography.labelLarge)
                ExposedDropdownMenuBox(
                    expanded = panelExpanded,
                    onExpandedChange = { panelExpanded = !panelExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedPanelSize,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Panel Filtresi Tipi") },
                        trailingIcon = {
                            Icon(
                                if (panelExpanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                contentDescription = null
                            )
                        },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )

                    ExposedDropdownMenu(
                        expanded = panelExpanded,
                        onDismissRequest = { panelExpanded = false }
                    ) {
                        panelSizeOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    selectedPanelSize = option
                                    panelExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(value = oilType, onValueChange = { oilType = it }, label = { Text("Yağ Kodu") })
                OutlinedTextField(value = oilLiter, onValueChange = { oilLiter = it }, label = { Text("Yağ (Litre)") })
                OutlinedTextField(value = estimatedHours, onValueChange = { estimatedHours = it }, label = { Text("Tahmini Saat") })
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Not") })
            }
        }
    )
}


@Composable
fun FilterEditRow(label: String, code: String, count: String, onChange: (String, String) -> Unit) {
    Column {
        Text(label)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                value = code,
                onValueChange = { onChange(it, count) },
                label = { Text("Kod") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = count,
                onValueChange = { onChange(code, it) },
                label = { Text("Adet") },
                modifier = Modifier.width(100.dp)
            )
        }
    }
}
