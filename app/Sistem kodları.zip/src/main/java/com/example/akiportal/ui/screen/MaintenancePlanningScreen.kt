package com.example.akiportal.ui.screen

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Green
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.Maintenance
import com.example.akiportal.model.SparePart
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.ui.theme.*
import com.example.akiportal.viewmodel.BakimViewModel
import java.text.SimpleDateFormat
import java.util.*
import androidx.navigation.NavController

@Composable
fun MaintenancePlanningScreen(
    machineId: String,
    machineName: String,
    defaultParts: List<SparePart>,
    bakimViewModel: BakimViewModel,
    navController: NavController
) {

    var description by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var responsible by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }

    val parts = remember { mutableStateListOf<SparePart>().apply { addAll(defaultParts) } }
    var extraParts by remember { mutableStateOf(listOf<SparePart>()) }

    var newExtraCode by remember { mutableStateOf("") }
    var newExtraQty by remember { mutableStateOf(1) }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        RedTopBar(
            title = "Planlanan Bakımlar",
            showMenu = true,
            menuContent = {
                DropdownMenuItem(
                    text = { Text("+") },
                    onClick = {
                        // TODO: OCR ekranına yönlendirme

                    }
                )
            }
        )




        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Açıklama") },
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.Gray)
            }
        )

        OutlinedTextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("Tarih (gg.aa.yyyy)") },
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                IconButton(onClick = {
                    val calendar = Calendar.getInstance()
                    DatePickerDialog(
                        context,
                        { _, year, month, day ->
                            val formatted = String.format("%02d.%02d.%04d", day, month + 1, year)
                            date = formatted
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                    ).show()
                }) {
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.Gray)
                }
            }
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text("Malzeme Seçimi:", color = White)

        parts.forEachIndexed { index, part ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = part.name, color = White, modifier = Modifier.weight(1f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        if (parts[index].quantity > 0) parts[index] =
                            parts[index].copy(quantity = part.quantity - 1)
                    }) { Text("-") }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${part.quantity}", color = White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Button(onClick = {
                        parts[index] = part.copy(quantity = part.quantity + 1)
                    }) { Text("+") }
                }
            }
        }

        Divider(color = Color.Gray, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))
        Text("Ekstra Malzeme Ekle:", color = White)

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newExtraCode,
                onValueChange = { newExtraCode = it },
                label = { Text("Malzeme Kodu") },
                modifier = Modifier.weight(1f),
                trailingIcon = {
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.Gray)
                }
            )
            Spacer(modifier = Modifier.width(6.dp))
            OutlinedTextField(
                value = newExtraQty.toString(),
                onValueChange = {
                    newExtraQty = it.toIntOrNull()?.coerceAtLeast(1) ?: 1
                },
                label = { Text("Adet") },
                modifier = Modifier.width(80.dp)
            )
            IconButton(onClick = {
                if (newExtraCode.isNotBlank()) {
                    extraParts = extraParts + SparePart(newExtraCode.trim(), newExtraQty)
                    newExtraCode = ""
                    newExtraQty = 1
                }
            }) {
                Icon(Icons.Default.Add, contentDescription = "Ekle", tint = Green)
            }
        }

        extraParts.forEach { extra ->
            Text("- ${extra.name} (${extra.quantity})", color = White)
        }

        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("Bakım Önü Not") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = responsible,
            onValueChange = { responsible = it },
            label = { Text("Sorumlu Kişi (İsteğe Bağlı)") },
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.Gray)
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val sdf = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
                val fullParts = parts + extraParts
                val maintenance = Maintenance(
                    machineId = machineId,
                    machineName = machineName,
                    plannedDate = date,
                    description = description,
                    note = note,
                    responsible = responsible,
                    parts = fullParts,
                    status = "planlandı"
                )
                bakimViewModel.planla(maintenance) {
                    submitted = true
                    description = ""
                    date = ""
                    note = ""
                    responsible = ""
                    extraParts = emptyList()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = RedPrimary)
        ) {
            Text("Bakımı Planla", color = White)
        }

        if (submitted) {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Bakım başarıyla planlandı.", color = Green)
        }
    }
}
