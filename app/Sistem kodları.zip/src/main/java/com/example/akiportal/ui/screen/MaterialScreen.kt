package com.example.akiportal.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.akiportal.viewmodel.MaterialViewModel
import com.example.akiportal.ui.components.AddCategoryDialog
import com.example.akiportal.ui.theme.*
import com.example.akiportal.util.PermissionManager
import com.example.akiportal.util.PermissionType
import kotlinx.coroutines.launch

@Composable
fun MaterialScreen(
    viewModel: MaterialViewModel = viewModel(),
    onCategoryClick: (String) -> Unit
) {
    val categories by viewModel.categories.collectAsState()
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var expandedMenu by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        // 🔴 Başlık ve Menü
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .background(RedPrimary)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Malzeme Kategorileri",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White
            )
            Box {
                IconButton(onClick = { expandedMenu = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = null, tint = Color.White)
                }
                DropdownMenu(
                    expanded = expandedMenu,
                    onDismissRequest = { expandedMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Yeni Kategori Ekle") },
                        onClick = {
                            if (PermissionManager.hasPermission(PermissionType.CATEGORY_ADD)) {
                                showAddCategoryDialog = true
                            } else {
                                scope.launch {
                                    snackbarHostState.showSnackbar("Bu işlem için yetkiniz yok.")
                                }
                            }
                            expandedMenu = false
                        }
                    )
                }
            }
        }

        // 🔻 Kategori Listesi
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(categories) { category ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onCategoryClick(category) },
                    colors = CardDefaults.cardColors(containerColor = DarkGray),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = category,
                            style = MaterialTheme.typography.titleMedium,
                            color = White
                        )
                    }
                }
            }
        }

        // 🔻 Kategori Ekle Dialog
        if (showAddCategoryDialog) {
            AddCategoryDialog(
                onDismiss = { showAddCategoryDialog = false },
                onAdd = {
                    viewModel.addCategory(it)
                    showAddCategoryDialog = false
                }
            )
        }

        SnackbarHost(hostState = snackbarHostState)
    }
}
