package com.example.akiportal.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.Maintenance
import com.example.akiportal.model.Machine
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale


@Composable
fun DailyMaintenanceScreen(
    date: String,
    maintenances: List<Maintenance>,
    onItemClick: (Maintenance) -> Unit,
    onBack: () -> Unit
) {
    val formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale("tr"))
    val dateObj = try {
        LocalDate.parse(date, formatter)
    } catch (e: Exception) {
        null
    }
    val prettyTitle = dateObj?.format(DateTimeFormatter.ofPattern("dd.MM.yyyy EEEE", Locale("tr"))) ?: date

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        RedTopBar(
            title = prettyTitle.replaceFirstChar { it.uppercase() },
            showMenu = false
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            items(maintenances) { maintenance ->
                val machine = maintenance.machineName
                val company = maintenance.companyName ?: "-"
                val serial = maintenance.serialNumber ?: "-"
                val note = maintenance.description
                val partCount = maintenance.parts.size
                val user = maintenance.responsible

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onItemClick(maintenance) },
                    colors = CardDefaults.cardColors(containerColor = CardDark)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "Şirket: $company", color = White, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Makine: $machine", color = LightGray)
                        Text(text = "Seri No: $serial", color = LightGray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Açıklama: $note", color = White)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Malzeme Sayısı: $partCount", color = LightGray)
                        Text(text = "Sorumlu: $user", color = LightGray)
                    }
                }
            }
        }
    }
}
