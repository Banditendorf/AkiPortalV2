package com.example.akiportal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.example.akiportal.model.User
import com.example.akiportal.ui.screen.AppNavigation
import com.example.akiportal.ui.theme.AkiPortalTheme
import com.example.akiportal.util.SharedPrefHelper
import com.example.akiportal.viewmodel.UserViewModel
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.*
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rememberedEmail = SharedPrefHelper.getSavedEmail(this)
        val isRemembered = SharedPrefHelper.isRemembered(this)

        setContent {
            AkiPortalTheme {
                val navController = rememberNavController()
                var isLoggedIn by remember { mutableStateOf(isRemembered) }

                val userViewModel: UserViewModel = viewModel()
                var currentUser by remember { mutableStateOf<User?>(null) }

                // 🔁 Giriş yapan kullanıcıyı çek
                LaunchedEffect(Unit) {
                    userViewModel.fetchCurrentUser()
                    userViewModel.currentUser.collect {
                        currentUser = it
                    }
                }

                // 🔄 Kullanıcı null ise yükleniyor göster
                if (currentUser == null && isLoggedIn) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }
                } else {
                    // 🔓 Giriş ekranı veya ana uygulama navigasyonu
                    AppNavigation(
                        navController = navController,
                        isLoggedIn = isLoggedIn,
                        currentUser = currentUser,
                        onLoginSuccess = { email ->
                            isLoggedIn = true
                            SharedPrefHelper.saveRememberMe(this@MainActivity, email)
                        },
                        onLogout = {
                            isLoggedIn = false
                            SharedPrefHelper.clearRememberMe(this@MainActivity)
                        }
                    )
                }
            }
        }
    }
}
