package com.example.akiportal.model

data class Maintenance(
    val id: String = "",
    val machineId: String = "",
    val machineName: String = "",
    val serialNumber: String = "",          // ✅ Bunu ekliyoruz
    val companyId: String = "",
    val companyName: String = "",
    val plannedDate: String = "",
    val status: String = "",
    val description: String = "",
    val note: String = "",
    val responsible: String = "",
    val parts: List<SparePart> = emptyList()
)
