package com.example.akiportal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.akiportal.model.Material

@Composable
fun EditMaterialDialog(
    material: Material,
    onDismiss: () -> Unit,
    onSave: (Material) -> Unit,
    onDelete: () -> Unit
) {
    var code by remember { mutableStateOf(material.code) }
    var brand by remember { mutableStateOf(material.brand) }
    var shelf by remember { mutableStateOf(material.shelf) }
    var stock by remember { mutableStateOf(material.stock.toString()) }
    var kritikStok by remember { mutableStateOf(material.kritikStok.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Malzemeyi Güncelle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Kod") })
                OutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text("Marka") })
                OutlinedTextField(value = shelf, onValueChange = { shelf = it }, label = { Text("Raf") })
                OutlinedTextField(value = stock, onValueChange = { stock = it }, label = { Text("Stok Adedi") })
                OutlinedTextField(value = kritikStok, onValueChange = { kritikStok = it }, label = { Text("Kritik Stok") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    material.copy(
                        code = code,
                        brand = brand,
                        shelf = shelf,
                        stock = stock.toIntOrNull() ?: material.stock,
                        kritikStok = kritikStok.toIntOrNull() ?: material.kritikStok
                    )
                )
            }) { Text("Kaydet") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) { Text("Sil") }
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = onDismiss) { Text("İptal") }
            }
        }
    )
}
