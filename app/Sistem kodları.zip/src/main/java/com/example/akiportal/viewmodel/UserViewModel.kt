package com.example.akiportal.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.akiportal.model.User
import com.example.akiportal.model.UserPermissions
import com.example.akiportal.util.LogHelper
import com.example.akiportal.util.PermissionManager
import com.example.akiportal.util.PermissionType
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class UserViewModel(application: Application) : AndroidViewModel(application) {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val context = application.applicationContext

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser

    private val _allUsers = MutableStateFlow<List<User>>(emptyList())
    val allUsers: StateFlow<List<User>> = _allUsers

    fun fetchCurrentUser() {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users").document(uid).get().addOnSuccessListener { doc ->
            val user = doc.toObject(User::class.java)
            _currentUser.value = user
            user?.permissions?.let { PermissionManager.setPermissions(it) }
        }.addOnFailureListener {
            _currentUser.value = null
        }
    }

    fun loadAllUsers() {
        db.collection("users").get().addOnSuccessListener { result ->
            val users = result.documents.mapNotNull { it.toObject(User::class.java) }
            _allUsers.value = users
        }.addOnFailureListener {
            _allUsers.value = emptyList()
        }
    }

    fun createUserWithAuth(
        email: String,
        password: String,
        fullName: String,
        isActive: Boolean,
        workPhone: String,
        personalPhone: String,
        permissions: UserPermissions,
        onError: (String) -> Unit = {},
        onSuccess: () -> Unit = {}
    ) {
        if (!PermissionManager.hasPermission(PermissionType.USER_ADD)) {
            PermissionManager.showNoPermissionMessage(context)
            return
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { authResult ->
                val uid = authResult.user?.uid ?: return@addOnSuccessListener
                val newUser = User(
                    uid = uid,
                    email = email,
                    fullName = fullName,
                    isActive = isActive,
                    workPhone = workPhone,
                    personalPhone = personalPhone,
                    permissions = permissions
                )
                db.collection("users").document(uid).set(newUser)
                LogHelper.logFirebaseAction(
                    userEmail = _currentUser.value?.email ?: "",
                    action = "Kullanıcı Eklendi",
                    details = mapOf("yeniKullaniciEmail" to email)
                )
                loadAllUsers()
                onSuccess()
            }
            .addOnFailureListener { e ->
                onError(e.localizedMessage ?: "Kullanıcı oluşturulamadı")
            }
    }

    fun deleteUser(uid: String) {
        if (!PermissionManager.hasPermission(PermissionType.USER_DELETE)) {
            PermissionManager.showNoPermissionMessage(context)
            return
        }
        db.collection("users").document(uid).delete()
        LogHelper.logFirebaseAction(
            userEmail = _currentUser.value?.email ?: "",
            action = "Kullanıcı Silindi",
            details = mapOf("uid" to uid)
        )
        loadAllUsers()
    }

    fun toggleUserActive(uid: String, newState: Boolean) {
        if (!PermissionManager.hasPermission(PermissionType.USER_AUTH)) {
            PermissionManager.showNoPermissionMessage(context)
            return
        }
        db.collection("users").document(uid).update("isActive", newState)
        LogHelper.logFirebaseAction(
            userEmail = _currentUser.value?.email ?: "",
            action = "Kullanıcı Aktifliği Değiştirildi",
            details = mapOf("uid" to uid, "yeniDurum" to newState)
        )
        loadAllUsers()
    }

    fun updateUserInfo(uid: String, fullName: String, workPhone: String, personalPhone: String, role: String) {
        db.collection("users").document(uid).update(
            mapOf(
                "fullName" to fullName,
                "workPhone" to workPhone,
                "personalPhone" to personalPhone,
                "role" to role
            )
        )
        LogHelper.logFirebaseAction(
            userEmail = _currentUser.value?.email ?: "",
            action = "Kullanıcı Bilgisi Güncellendi",
            details = mapOf("uid" to uid)
        )
        loadAllUsers()
    }


    fun updateUserPermissions(uid: String, permissions: UserPermissions) {
        if (!PermissionManager.hasPermission(PermissionType.USER_AUTH)) {
            PermissionManager.showNoPermissionMessage(context)
            return
        }
        db.collection("users").document(uid).update("permissions", permissions)
        LogHelper.logFirebaseAction(
            userEmail = _currentUser.value?.email ?: "",
            action = "Kullanıcı Yetkileri Güncellendi",
            details = mapOf("uid" to uid)
        )
        loadAllUsers()
    }
}
