package com.example.akiportal.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.akiportal.model.*
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.ui.theme.*
import com.example.akiportal.viewmodel.BakimViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

@Composable
fun PreparationDetailScreen(
    maintenance: Maintenance,
    onBack: () -> Unit,
    currentUser: User,
    bakimViewModel: BakimViewModel = viewModel()
) {
    val allParts = maintenance.parts
    val preparedMap = remember {
        mutableStateMapOf<String, Boolean>().apply {
            allParts.forEach { put(it.name, it.prepared ?: false) }
        }
    }

    val scope = rememberCoroutineScope()
    var materialMap by remember { mutableStateOf<Map<String, Material>>(emptyMap()) }
    var machine by remember { mutableStateOf<Machine?>(null) }
    var company by remember { mutableStateOf<Company?>(null) }
    val allPrepared = preparedMap.values.all { it }

    var showManualAddDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }

    LaunchedEffect(true) {
        val firestore = FirebaseFirestore.getInstance()

        val materialSnap = firestore.collection("materials").get().await()
        materialMap = materialSnap.documents.mapNotNull {
            val mat = it.toObject(Material::class.java)
            mat?.code?.let { code -> code to mat }
        }.toMap()

        val machineSnap = firestore.collection("machines").document(maintenance.machineId).get().await()
        machine = machineSnap.toObject(Machine::class.java)

        machine?.companyId?.let { companyId ->
            val companySnap = firestore.collection("companies").document(companyId).get().await()
            company = companySnap.toObject(Company::class.java)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        // RedTopBar + Menü
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BackgroundDark)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Hazırlık Detayı", fontSize = 20.sp, color = White)

            Box {
                IconButton(onClick = { expanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Menü", tint = White)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    DropdownMenuItem(
                        text = { Text("Listeyi Sil") },
                        onClick = {
                            expanded = false
                            showDeleteConfirm = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Manuel Liste Ekle") },
                        onClick = {
                            expanded = false
                            showManualAddDialog = true
                        }
                    )
                }
            }
        }

        // Üstte Şirket & Makine Bilgisi
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardDark)
        ) {
            Column(Modifier.padding(12.dp)) {
                Text("Şirket: ${company?.name ?: "-"}", color = White)
                Text("Makine: ${machine?.name ?: maintenance.machineName}", color = White)
                Text("Seri No: ${machine?.serialNumber ?: "-"}", color = LightGray)
            }
        }

        // Malzeme Listesi
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(allParts) { part ->
                val isPrepared = preparedMap[part.name] == true
                val material = materialMap[part.name]

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onLongClick = {
                                val newState = !isPrepared
                                preparedMap[part.name] = newState
                            },
                            onClick = {}
                        ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPrepared) Green.copy(alpha = 0.3f) else CardDark
                    )
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Kategori: ${material?.category ?: "-"}", color = White)
                            Text("Parça Kodu: ${part.name}", color = White)
                        }
                        Spacer(Modifier.height(4.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Raf: ${material?.shelf ?: "-"}", color = LightGray)
                            Text("Adet: ${part.quantity}", color = LightGray)
                        }

                        if (isPrepared) {
                            Spacer(Modifier.height(4.dp))
                            Text("✅ Hazırlandı", color = Green, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        // Onay Butonu
        Button(
            onClick = {
                val updatedParts = allParts.map {
                    it.copy(prepared = true)
                }
                val updated = maintenance.copy(
                    parts = updatedParts,
                    note = "${maintenance.note} - Hazırlayan: ${currentUser.fullName}"
                )
                bakimViewModel.updateMaintenance(updated) {
                    onBack()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (allPrepared) Green else Gray),
            enabled = allPrepared
        ) {
            Text("Hazırlık Tamamlandı", color = White)
        }
    }

    // Silme Onayı
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            confirmButton = {
                TextButton(onClick = {
                    FirebaseFirestore.getInstance().collection("plannedMaintenances")
                        .document(maintenance.id)
                        .delete()
                    showDeleteConfirm = false
                    onBack()
                }) { Text("Sil") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("İptal") }
            },
            title = { Text("Listeyi Sil") },
            text = { Text("Bu planı silmek istediğinize emin misiniz?") }
        )
    }

}

