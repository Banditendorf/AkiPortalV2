package com.example.akiportal.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.akiportal.model.*
import com.example.akiportal.ui.components.*
import com.example.akiportal.ui.theme.*
import com.example.akiportal.util.PermissionManager
import com.example.akiportal.util.PermissionType
import com.example.akiportal.viewmodel.BakimViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

@Composable
fun MachineDetailScreen(
    machine: Machine,
    navController: NavController, // 🔺 Yeni parametre
    bakimViewModel: BakimViewModel = viewModel()
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var maintenanceList by remember { mutableStateOf(listOf<Maintenance>()) }
    var showPlanDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showEditMachineDialog by remember { mutableStateOf(false) }

    LaunchedEffect(machine.id) {
        FirebaseFirestore.getInstance()
            .collection("plannedMaintenances")
            .whereEqualTo("machineId", machine.id)
            .get()
            .addOnSuccessListener { result ->
                maintenanceList = result.documents.mapNotNull { it.toObject(Maintenance::class.java) }
            }
    }

    Column(Modifier.fillMaxSize().background(BackgroundDark)) {
        RedTopBar(title = machine.name, showMenu = true) {
            DropdownMenuItem(text = { Text("Makineyi Güncelle") }, onClick = {
                if (PermissionManager.hasPermission(PermissionType.MACHINE_UPDATE)) {
                    showEditMachineDialog = true
                } else scope.launch {
                    snackbarHostState.showSnackbar("Makine güncelleme yetkiniz yok.")
                }
            })
            DropdownMenuItem(text = { Text("Makineyi Sil") }, onClick = {
                if (PermissionManager.hasPermission(PermissionType.MACHINE_DELETE)) {
                    showDeleteConfirm = true
                } else scope.launch {
                    snackbarHostState.showSnackbar("Makine silme yetkiniz yok.")
                }
            })
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            colors = CardDefaults.cardColors(containerColor = White)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Seri No: ${machine.serialNumber}", fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                InfoRow("Yağ Filtresi:", machine.oilFilterCode, "${machine.oilFilterCount} adet")
                InfoRow("Separatör:", machine.separatorCode, "${machine.separatorCount} adet")
                InfoRow("Hava Filtresi:", machine.airFilterCode, "${machine.airFilterCount} adet")
                InfoRow("Kurutucu Filtresi:", machine.dryerFilterCode, "${machine.dryerFilterCount} adet")
                InfoRow("Yağ:", machine.oilCode, "${machine.oilLiter} L")
                InfoRow("Panel Filtresi:", machine.panelFilterSize, "")
                InfoRow("Tahmini Çalışma Saati:", formatHoursToTime(machine.estimatedHours), "")
                InfoRow("Sıradaki Bakım Saati:", "${machine.nextMaintenanceHour} saat", "")

                machine.note.takeIf { it.isNotBlank() }?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Not: $it", color = Color.Black)
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Button(
                onClick = { showPlanDialog = true },
                modifier = Modifier
                    .fillMaxWidth(0.9f) // buton ekranın %90'ını kaplar (3 kat görünüm)
                    .height(48.dp),     // mevcut yüksekliği koru (Material default: 48.dp)
                colors = ButtonDefaults.buttonColors(containerColor = RedPrimary)
            ) {
                Text("Bakım Oluştur", color = White)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Geçmiş", color = White, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(maintenanceList) { maintenance ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.DarkGray)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Tarih: ${maintenance.plannedDate}", color = Color.White)
                        Text("Durum: ${maintenance.status}", color = Color.White)
                        Text("Not: ${maintenance.note ?: ""}", color = Color.White)
                    }
                }
            }
        }
    }

    if (showPlanDialog) {
        MaintenancePlanningScreen(
            machineId = machine.id,
            machineName = machine.name,
            defaultParts = listOf(
                SparePart(machine.airFilterCode, machine.airFilterCount),
                SparePart(machine.oilFilterCode, machine.oilFilterCount),
                SparePart(machine.separatorCode, machine.separatorCount),
                SparePart(machine.dryerFilterCode, machine.dryerFilterCount)
            ),
            bakimViewModel = bakimViewModel,
            navController = navController // 🔺 BURASI EKSİKTİ
        )
    }


    if (showDeleteConfirm) {
        ConfirmDeleteDialog(
            text = "Bu makineyi silmek istediğinize emin misiniz?",
            onConfirm = {
                FirebaseFirestore.getInstance().collection("machines").document(machine.id).delete()
                showDeleteConfirm = false
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }

    if (showEditMachineDialog) {
        EditMachineDialog(
            machine = machine,
            onDismiss = { showEditMachineDialog = false },
            onUpdated = { showEditMachineDialog = false }
        )
    }

    SnackbarHost(hostState = snackbarHostState)
}

@Composable
fun InfoRow(label: String, center: String?, right: String?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.Black, modifier = Modifier.weight(1f))
        Text(center ?: "-", color = Color.DarkGray, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Text(right ?: "", color = Color.DarkGray, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
    }
}


@Composable
fun ConfirmDeleteDialog(
    title: String = "Silme Onayı",
    text: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("Evet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        },
        title = { Text(title) },
        text = { Text(text) }
    )
}
fun formatHoursToTime(hours: Int): String {
    val totalSeconds = hours * 3600
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return String.format("%02d:%02d:%02d", h, m, s)
}