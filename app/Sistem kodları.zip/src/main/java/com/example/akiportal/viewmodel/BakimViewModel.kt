package com.example.akiportal.viewmodel

import androidx.lifecycle.ViewModel
import com.example.akiportal.model.Maintenance
import com.example.akiportal.model.SparePart
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class BakimViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()

    fun planla(bakim: Maintenance, onComplete: () -> Unit) {
        val id = if (bakim.id.isBlank()) UUID.randomUUID().toString() else bakim.id

        // Makine bilgilerini çekerek seri numara ve şirket bilgilerini ekle
        db.collection("machines").document(bakim.machineId).get().addOnSuccessListener { snapshot ->
            val serial = snapshot.getString("serialNumber") ?: ""
            val companyId = snapshot.getString("companyId") ?: ""
            val companyName = snapshot.getString("companyName") ?: ""

            val updatedBakim = bakim.copy(
                id = id,
                serialNumber = serial,
                companyId = companyId,
                companyName = companyName
            )

            db.collection("plannedMaintenances")
                .document(id)
                .set(updatedBakim)
                .addOnSuccessListener { onComplete() }
        }
    }

    fun updateMaintenance(maintenance: Maintenance, onComplete: () -> Unit) {
        db.collection("plannedMaintenances")
            .document(maintenance.id)
            .set(maintenance)
            .addOnSuccessListener { onComplete() }
    }

    fun updatePreparation(bakimId: String, parts: List<SparePart>) {
        db.collection("plannedMaintenances")
            .document(bakimId)
            .update("parts", parts)
    }

    fun tamamlandiOlarakIsaretle(bakimId: String) {
        db.collection("plannedMaintenances")
            .document(bakimId)
            .update("status", "tamamlandı")
    }

    fun getPlannedList(onResult: (List<Maintenance>) -> Unit) {
        db.collection("plannedMaintenances")
            .whereEqualTo("status", "planlandı")
            .get()
            .addOnSuccessListener { result ->
                val list = result.mapNotNull { it.toObject(Maintenance::class.java) }
                onResult(list)
            }
    }

    fun decreaseStock(code: String, quantity: Int) {
        val docRef = db.collection("materials").document(code)
        docRef.get().addOnSuccessListener { snapshot ->
            val currentStock = snapshot.getLong("stock") ?: 0L
            val newStock = (currentStock - quantity).coerceAtLeast(0)
            docRef.update("stock", newStock)
        }
    }
}
