package com.example.akiportal.model

data class Material(
    val code: String = "",
    val brand: String = "",
    val shelf: String = "",
    val category: String = "",
    val stock: Int = 0,
    val kritikStok: Int = 0
)
