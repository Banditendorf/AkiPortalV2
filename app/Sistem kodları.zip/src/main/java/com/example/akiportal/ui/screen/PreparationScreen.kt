package com.example.akiportal.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.akiportal.model.*
import com.example.akiportal.ui.components.RedTopBar
import com.example.akiportal.ui.theme.*
import com.example.akiportal.viewmodel.BakimViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.launch


@Composable
fun PreparationScreen(
    bakimViewModel: BakimViewModel = viewModel(),
    onMaintenanceClick: (Maintenance) -> Unit
) {
    val formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")
    var maintenanceList by remember { mutableStateOf(emptyList<Maintenance>()) }
    var machineMap by remember { mutableStateOf<Map<String, Machine>>(emptyMap()) }
    var companyMap by remember { mutableStateOf<Map<String, Company>>(emptyMap()) }
    val selectedToDelete = remember { mutableStateOf<Maintenance?>(null) }
    val showManualAddDialog = remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    suspend fun refreshData() {
        val today = LocalDate.now()
        val firestore = FirebaseFirestore.getInstance()

        val snapshot = firestore.collection("plannedMaintenances")
            .whereEqualTo("status", "planlandı")
            .get().await()

        val allMaintenances = snapshot.mapNotNull { it.toObject(Maintenance::class.java) }

        val filtered = allMaintenances.filter {
            try {
                it.plannedDate.isNotBlank() &&
                        LocalDate.parse(it.plannedDate, formatter).isAfter(today.minusDays(1))
            } catch (e: Exception) {
                false
            }
        }.sortedWith(
            compareByDescending<Maintenance> { it.parts.any { p -> !p.prepared } }
                .thenByDescending { it.plannedDate }
        )

        maintenanceList = filtered

        val machineIds = filtered.map { it.machineId }.distinct()
        val machines = machineIds.mapNotNull { id ->
            val doc = firestore.collection("machines").document(id).get().await()
            doc.toObject(Machine::class.java)?.let { id to it }
        }.toMap()
        machineMap = machines

        val companyIds = machines.values.map { it.companyId }.distinct()
        val companies = companyIds.mapNotNull { id ->
            val doc = firestore.collection("companies").document(id).get().await()
            doc.toObject(Company::class.java)?.let { id to it }
        }.toMap()
        companyMap = companies
    }

    LaunchedEffect(true) {
        coroutineScope.launch {
            refreshData()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        // Top Bar
        Row()
        {
            RedTopBar("Malzeme Hazırlıkları")

            Box {
                IconButton(onClick = { expanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Menü", tint = White)
                }
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Listeyi Sil") },
                        onClick = {
                            expanded = false
                            selectedToDelete.value = maintenanceList.firstOrNull()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Manuel Liste Ekle") },
                        onClick = {
                            expanded = false
                            showManualAddDialog.value = true
                        }
                    )
                }
            }
        }

        if (maintenanceList.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Hazırlanacak liste yok", fontSize = 20.sp, color = White)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                var dividerDrawn = false

                maintenanceList.forEach { maintenance ->
                    val machine = machineMap[maintenance.machineId]
                    val company = machine?.companyId?.let { companyMap[it] }
                    val allPrepared = maintenance.parts.all { it.prepared == true }

                    if (!dividerDrawn && allPrepared) {
                        dividerDrawn = true
                        item {
                            Divider(
                                modifier = Modifier.padding(vertical = 8.dp),
                                color = Gray.copy(alpha = 0.4f),
                                thickness = 1.dp
                            )
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onMaintenanceClick(maintenance) },
                            colors = CardDefaults.cardColors(
                                containerColor = if (allPrepared) Green.copy(alpha = 0.15f) else CardDark
                            )
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Şirket: ${company?.name ?: "-"}", color = White, fontSize = 16.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Makine: ${machine?.name ?: maintenance.machineName}", color = LightGray, fontSize = 14.sp)
                                if (allPrepared && maintenance.note.contains("Hazırlayan")) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    val hazirlayan = maintenance.note.split("Hazırlayan:").getOrNull(1)?.trim() ?: "-"
                                    Text("Hazırlayan: $hazirlayan", color = LightGray, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Silme Dialog
    selectedToDelete.value?.let { itemToDelete ->
        AlertDialog(
            onDismissRequest = { selectedToDelete.value = null },
            confirmButton = {
                TextButton(onClick = {
                    FirebaseFirestore.getInstance()
                        .collection("plannedMaintenances")
                        .document(itemToDelete.id)
                        .delete()
                        .addOnSuccessListener {
                            selectedToDelete.value = null
                            coroutineScope.launch { refreshData() }
                        }
                }) { Text("Sil") }
            },
            dismissButton = {
                TextButton(onClick = { selectedToDelete.value = null }) { Text("İptal") }
            },
            title = { Text("Listeyi Sil") },
            text = { Text("Bu bakım planını silmek istediğinize emin misiniz?") }
        )
    }

    if (showManualAddDialog.value) {
        ManualAddDialog(onDismiss = { showManualAddDialog.value = false })
    }
}


@Composable
fun ManualAddDialog(onDismiss: () -> Unit) {
    var machineName by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                // buraya manuel listeyi Firestore’a ekle
                onDismiss()
            }) { Text("Ekle") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        },
        title = { Text("Manuel Liste Ekle") },
        text = {
            Column {
                OutlinedTextField(
                    value = machineName,
                    onValueChange = { machineName = it },
                    label = { Text("Makine Adı") }
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("Tarih (dd.MM.yyyy)") }
                )
            }
        }
    )
}